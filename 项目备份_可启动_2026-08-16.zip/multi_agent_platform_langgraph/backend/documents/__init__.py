"""Teaching document ingestion."""
