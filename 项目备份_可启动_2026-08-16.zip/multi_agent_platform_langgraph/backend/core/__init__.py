"""Shared application infrastructure."""
