"""Runtime model configuration."""
