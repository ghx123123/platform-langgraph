import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertCircle, ArrowDown, ArrowLeft, ArrowUp, BookOpen, Check, CheckCircle2,
  Database, Edit3, ExternalLink, FilePlus2, FileSearch, Files, GitMerge, Link2, Loader2,
  Plus, RefreshCw, Save, Send, Trash2, Unlink, X,
} from 'lucide-react';
import { courseDesignApi, documentApi, getErrorMessage, materialUnitApi } from '../lib/api';
import type {
  CourseDesignRecord, MaterialUnitFileAnalysis, MaterialUnitKnowledgeNode, MaterialUnitKnowledgeOutline, MaterialUnitRefineTask,
  MaterialUnitRecord, MaterialUnitScopeAlignment, MaterialUnitScopeOptions, MaterialUnitSummary,
  SyllabusRequirementType,
} from '../types/workflow';
import './MaterialUnitWorkspace.css';

interface Props {
  refreshKey: number;
  onGoLibrary: () => void;
  onCourseDesignCreated: (design: CourseDesignRecord) => void | Promise<void>;
}

type Dialog =
  | { mode: 'rename'; unit: MaterialUnitSummary; title: string }
  | { mode: 'delete'; unit: MaterialUnitSummary }
  | { mode: 'merge'; target: MaterialUnitSummary; sourceIds: string[]; title: string }
  | { mode: 'link-files'; target: MaterialUnitSummary; sourceUnitId: string; materialIds: string[] }
  | { mode: 'delete-outline'; outline: MaterialUnitKnowledgeOutline; allHistory: boolean }
  | { mode: 'import-design'; outlineKey: string; materialIds: string[]; primaryMaterialId: string };

const categoryLabels: Record<string, string> = {
  syllabus: '教学大纲', schedule: '教学进度', textbook: '教材', courseware: '课件', lesson_plan: '教案',
  experiment: '实验', code: '代码', teaching_record: '教学记录', review: '审核材料', interactive: '交互资源',
  reference: '参考资料', media: '媒体', other: '其他',
};
const requirementLabels: Record<SyllabusRequirementType, string> = {
  objective: '课程目标', knowledge: '知识要求', key_point: '教学重点', difficult_point: '教学难点',
  practice: '实践要求', assessment: '考核要求',
};

function formatDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).format(date);
}

function latestOutlines(items: MaterialUnitKnowledgeOutline[]) {
  const latest = new Map<string, MaterialUnitKnowledgeOutline>();
  items.forEach((item) => {
    const current = latest.get(item.id);
    if (!current || item.version > current.version) latest.set(item.id, item);
  });
  return [...latest.values()].sort((a, b) => b.updated_at.localeCompare(a.updated_at));
}

export function MaterialUnitWorkspace({ refreshKey, onGoLibrary, onCourseDesignCreated }: Props) {
  const [units, setUnits] = useState<MaterialUnitSummary[]>([]);
  const [unit, setUnit] = useState<MaterialUnitRecord | null>(null);
  const [scope, setScope] = useState<MaterialUnitScopeOptions | null>(null);
  const [alignment, setAlignment] = useState<MaterialUnitScopeAlignment | null>(null);
  const [outlines, setOutlines] = useState<MaterialUnitKnowledgeOutline[]>([]);
  const [outline, setOutline] = useState<MaterialUnitKnowledgeOutline | null>(null);
  const [selectedSession, setSelectedSession] = useState('');
  const [selectedRequirements, setSelectedRequirements] = useState<string[]>([]);
  const [selectedTextbook, setSelectedTextbook] = useState<string[]>([]);
  const [draftNodes, setDraftNodes] = useState<MaterialUnitKnowledgeNode[]>([]);
  const [draftTitle, setDraftTitle] = useState('');
  const [outlineEditing, setOutlineEditing] = useState(false);
  const [refineOpen, setRefineOpen] = useState(false);
  const [refineMaterials, setRefineMaterials] = useState<string[]>([]);
  const [refineInstruction, setRefineInstruction] = useState('');
  const [previewFile, setPreviewFile] = useState<MaterialUnitFileAnalysis | null>(null);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [loading, setLoading] = useState(true);
  const [detailLoading, setDetailLoading] = useState(false);
  const [matching, setMatching] = useState(false);
  const [mutating, setMutating] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [refineTask, setRefineTask] = useState<MaterialUnitRefineTask | null>(null);

  const selectOutline = useCallback((next: MaterialUnitKnowledgeOutline | null) => {
    setOutline(next);
    setDraftTitle(next?.title || '');
    setDraftNodes(next?.nodes.map((node) => ({ ...node, evidence: node.evidence.map((item) => ({ ...item })) })) || []);
    setOutlineEditing(false);
    if (next) {
      setSelectedSession(next.selected_session_ids[0] || '');
      setSelectedRequirements(next.selected_syllabus_item_ids);
      setSelectedTextbook(next.selected_textbook_node_ids);
    }
  }, []);

  const openUnit = useCallback(async (unitId: string) => {
    setDetailLoading(true); setError(''); setAlignment(null);
    try {
      const [record, options, outlineResponse] = await Promise.all([
        materialUnitApi.get(unitId), materialUnitApi.scopeOptions(unitId), materialUnitApi.listKnowledgeOutlines(unitId, true),
      ]);
      setUnit(record); setScope(options); setOutlines(outlineResponse.items);
      const latest = latestOutlines(outlineResponse.items)[0] || null;
      selectOutline(latest);
      if (latest) {
        const taskResponse = await materialUnitApi.listRefineTasks(unitId, latest.id);
        const visibleTask = taskResponse.items.find((item) =>
          !['completed', 'failed'].includes(item.status)
          || item.result_version === latest.version
          || item.base_version === latest.version,
        );
        setRefineTask(visibleTask || null);
      } else setRefineTask(null);
      if (!latest) {
        setSelectedSession(''); setSelectedRequirements([]); setSelectedTextbook([]);
      }
    } catch (reason) { setError(getErrorMessage(reason)); }
    finally { setDetailLoading(false); }
  }, [selectOutline]);

  useEffect(() => {
    if (!unit || !refineTask || ['completed', 'failed'].includes(refineTask.status)) return;
    const timer = window.setInterval(async () => {
      try {
        const next = await materialUnitApi.getRefineTask(unit.id, refineTask.outline_id, refineTask.id);
        setRefineTask(next);
        if (next.status === 'completed') {
          const response = await materialUnitApi.listKnowledgeOutlines(unit.id, true);
          setOutlines(response.items);
          const result = response.items.find((item) => item.id === next.outline_id && item.version === next.result_version);
          if (result) selectOutline(result);
          setRefineOpen(false); setRefineMaterials([]); setRefineInstruction('');
          setNotice(`细化任务已完成，结果已保存为第 ${next.result_version} 版。`);
        }
        if (next.status === 'failed') setError(next.error || '知识大纲细化未完成。');
      } catch (reason) { setError(getErrorMessage(reason)); }
    }, 1500);
    return () => window.clearInterval(timer);
  }, [refineTask?.id, refineTask?.status, refineTask?.outline_id, unit?.id, selectOutline]);

  const refresh = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const response = await materialUnitApi.list();
      setUnits(response.items);
      const target = unit && response.items.some((item) => item.id === unit.id) ? unit.id : response.items[0]?.id;
      if (target) await openUnit(target); else { setUnit(null); setScope(null); setOutlines([]); selectOutline(null); }
    } catch (reason) { setError(getErrorMessage(reason)); }
    finally { setLoading(false); }
  }, [openUnit, selectOutline, unit]);

  useEffect(() => { void refresh(); }, [refreshKey]);

  const runMatch = async (sessionId: string) => {
    if (!unit || !sessionId) return;
    setSelectedSession(sessionId); setMatching(true); setError(''); setSelectedRequirements([]);
    try {
      const result = await materialUnitApi.syllabusMatches(unit.id, [sessionId]);
      setAlignment(result);
      setSelectedRequirements(result.matches.filter((item) => item.recommended).map((item) => item.id));
    } catch (reason) { setError(getErrorMessage(reason)); setAlignment(null); }
    finally { setMatching(false); }
  };

  const toggle = (values: string[], value: string, setter: (next: string[]) => void) => {
    setter(values.includes(value) ? values.filter((item) => item !== value) : [...values, value]);
  };

  const createOutline = async () => {
    if (!unit || !selectedSession) return;
    setMutating(true); setError('');
    try {
      const created = await materialUnitApi.createKnowledgeOutline(unit.id, {
        teaching_item_ids: [selectedSession], syllabus_item_ids: selectedRequirements,
        outline_node_ids: selectedTextbook, status: 'draft',
      });
      setOutlines((current) => [...current, created]); selectOutline(created);
      setNotice('知识大纲已生成并保存为第 1 版。');
    } catch (reason) { setError(getErrorMessage(reason)); }
    finally { setMutating(false); }
  };

  const saveOutlineVersion = async (status: 'draft' | 'confirmed' = outline?.status || 'draft') => {
    if (!unit || !outline || !draftTitle.trim() || !draftNodes.length) return;
    setMutating(true); setError('');
    try {
      const saved = await materialUnitApi.updateKnowledgeOutline(unit.id, outline.id, {
        base_version: outline.version, title: draftTitle.trim(), status, nodes: draftNodes,
        change_summary: status === 'confirmed' ? '教师确认知识范围' : '教师编辑知识大纲',
      });
      setOutlines((current) => [...current, saved]); selectOutline(saved);
      setNotice(`已保存第 ${saved.version} 版知识大纲。`);
    } catch (reason) { setError(getErrorMessage(reason)); }
    finally { setMutating(false); }
  };

  const refineOutline = async () => {
    if (!unit || !outline || !refineMaterials.length || refineInstruction.trim().length < 2) return;
    setMutating(true); setError('');
    try {
      const task = await materialUnitApi.createRefineTask(unit.id, outline.id, {
        material_ids: refineMaterials, teacher_instruction: refineInstruction.trim(), base_version: outline.version, use_model: true,
      });
      setRefineTask(task);
      setNotice('细化任务已在后台启动，可以切换页面，返回后会继续显示进度。');
    } catch (reason) { setError(getErrorMessage(reason)); }
    finally { setMutating(false); }
  };

  const importToDesign = async () => {
    if (!unit || !dialog || dialog.mode !== 'import-design') return;
    const [outlineId, versionText] = dialog.outlineKey.split(':');
    const selectedOutline = outlines.find((item) => item.id === outlineId && item.version === Number(versionText));
    if (!selectedOutline) return;
    setMutating(true); setError('');
    try {
      const design = await courseDesignApi.create({
        archive_id: unit.archive_id, material_ids: dialog.materialIds, primary_material_id: dialog.primaryMaterialId,
        material_unit_id: unit.id, knowledge_outline_id: selectedOutline.id, knowledge_outline_version: selectedOutline.version,
      });
      setDialog(null); setNotice(`知识大纲 v${selectedOutline.version} 与 ${dialog.materialIds.length} 份确认资料已导入课程设计。`);
      await onCourseDesignCreated(design);
    } catch (reason) { setError(getErrorMessage(reason)); }
    finally { setMutating(false); }
  };

  const submitDialog = async () => {
    if (!dialog) return;
    setMutating(true); setError('');
    try {
      if (dialog.mode === 'rename') await materialUnitApi.rename(dialog.unit.id, dialog.title.trim());
      if (dialog.mode === 'delete') await materialUnitApi.remove(dialog.unit.id);
      if (dialog.mode === 'merge') await materialUnitApi.merge(dialog.target.id, dialog.sourceIds, dialog.title.trim());
      if (dialog.mode === 'link-files') await materialUnitApi.referenceMaterials(dialog.target.id, dialog.sourceUnitId, dialog.materialIds);
      if (dialog.mode === 'delete-outline') await materialUnitApi.deleteKnowledgeOutline(unit!.id, dialog.outline.id, dialog.outline.version, dialog.allHistory);
      if (dialog.mode === 'import-design') { await importToDesign(); return; }
      setDialog(null); await refresh();
      setNotice(dialog.mode === 'merge' ? '资料已整合为一个单元。' : dialog.mode === 'link-files' ? '已关联所选文件，来源单元保持不变。' : dialog.mode === 'delete-outline' ? '知识大纲历史已更新。' : '操作已完成。');
    } catch (reason) { setError(getErrorMessage(reason)); }
    finally { setMutating(false); }
  };

  const removeFileReference = async (referenceId: string) => {
    if (!unit) return;
    setMutating(true);
    try { const saved = await materialUnitApi.removeMaterialReference(unit.id, referenceId); setUnit(saved); setNotice('已解除文件关联，来源文件未删除。'); }
    catch (reason) { setError(getErrorMessage(reason)); }
    finally { setMutating(false); }
  };

  const availableFiles = useMemo(() => unit ? [
    ...unit.files.map((file) => ({ ...file, sourceLabel: unit.title })),
    ...unit.linked_units.flatMap((linked) => linked.files.map((file) => ({ ...file, sourceLabel: linked.title }))),
    ...unit.material_references.map((reference) => ({ ...reference.file, sourceLabel: reference.source_unit_title })),
  ].filter((file, index, values) => values.findIndex((item) => item.material_id === file.material_id) === index) : [], [unit]);
  const designImportFiles = useMemo(
    () => availableFiles.filter((file) => !file.archive_id || file.archive_id === unit?.archive_id),
    [availableFiles, unit?.archive_id],
  );

  const latest = latestOutlines(outlines);
  const sessionItem = scope?.teaching_items.find((item) => item.id === selectedSession);

  if (loading && !units.length) return <div className="material-unit-loading"><Loader2 className="spin" size={22} /><strong>正在读取资料单元…</strong></div>;
  return <div className="material-unit-workspace">
    <header className="material-unit-toolbar">
      <div><span>资料单元</span><h2>建立本次课知识范围</h2><p>先选讲次，系统匹配相关大纲要求，再用教材章节形成可追溯的知识大纲。</p></div>
      <div><button type="button" onClick={() => void refresh()} disabled={loading}><RefreshCw className={loading ? 'spin' : ''} size={16} />刷新</button><button type="button" onClick={onGoLibrary}><ArrowLeft size={16} />课程资料库</button></div>
    </header>
    {(error || notice) && <div className={`material-unit-message ${error ? 'is-error' : ''}`}><AlertCircle size={16} /><span>{error || notice}</span><button type="button" onClick={() => { setError(''); setNotice(''); }} aria-label="关闭提示"><X size={15} /></button></div>}
    {!units.length ? <main className="material-unit-empty"><Database size={30} /><h3>还没有资料单元</h3><p>请先到课程资料库选择进度表、大纲和教材。</p><button type="button" onClick={onGoLibrary}>前往课程资料库</button></main> : <div className="material-unit-layout">
      <aside className="unit-sidebar">
        <header><strong>单元列表</strong><span>{units.length}</span></header>
        <div className="unit-list">{units.map((item) => <div key={item.id} className={`unit-list-item ${unit?.id === item.id ? 'active' : ''}`}><button type="button" onClick={() => void openUnit(item.id)}><Database size={17} /><span><strong>{item.title}</strong><small>{item.material_count} 份资料 · {item.linked_unit_count} 个关联</small><time>{formatDate(item.updated_at)}</time></span></button><div><button type="button" title="重命名" onClick={() => setDialog({ mode: 'rename', unit: item, title: item.title })}><Edit3 size={14} /></button><button type="button" title="删除" onClick={() => setDialog({ mode: 'delete', unit: item })}><Trash2 size={14} /></button></div></div>)}</div>
        <footer><button type="button" disabled={!unit || units.length < 2} onClick={() => unit && setDialog({ mode: 'link-files', target: unit, sourceUnitId: '', materialIds: [] })}><Link2 size={15} />关联其他单元资料</button><button type="button" disabled={!unit || units.length < 2} onClick={() => unit && setDialog({ mode: 'merge', target: unit, sourceIds: [], title: unit.title })}><GitMerge size={15} />整合为一个单元</button></footer>
        {unit && <section className="unit-sources"><header><strong>当前资料</strong><span>{availableFiles.length}</span></header>{availableFiles.map((file) => <button type="button" key={file.material_id} onClick={() => setPreviewFile(file)}><Files size={15} /><span><strong>{file.name}</strong><small>{categoryLabels[file.category] || file.category} · {file.sourceLabel}</small></span></button>)}{unit.material_references.map((reference) => <div className="file-reference" key={reference.id}><Link2 size={14} /><span><strong>{reference.file.name}</strong><small>关联自 {reference.source_unit_title}</small></span><button type="button" onClick={() => void removeFileReference(reference.id)} title="解除关联"><Unlink size={14} /></button></div>)}</section>}
      </aside>

      <main className="scope-workbench">
        {detailLoading ? <div className="material-unit-loading"><Loader2 className="spin" size={22} /><strong>正在整理讲次、大纲和教材…</strong></div> : <>
          <section className="planning-step is-open"><header><span>1</span><div><strong>选择本次课</strong><small>从进度表中选择一条课程安排</small></div><em>{selectedSession ? '已选择' : '待选择'}</em></header><div className="session-options">{scope?.teaching_items.length ? scope.teaching_items.map((item) => <button type="button" key={item.id} className={selectedSession === item.id ? 'selected' : ''} onClick={() => void runMatch(item.id)}><span className="radio-mark">{selectedSession === item.id && <Check size={13} />}</span><span><strong>{item.title}</strong><small>{item.content}</small><em>来源：{item.source_name}</em></span></button>) : <p className="step-empty">尚未识别到进度表，请关联或导入进度表文件。</p>}</div></section>

          <section className={`planning-step ${selectedSession ? 'is-open' : ''}`}><header><span>2</span><div><strong>核对相关大纲要求</strong><small>系统只展示与当前讲次相关的目标、重点和难点</small></div><em>{matching ? '匹配中' : alignment ? `${alignment.matches.length}/${alignment.total_candidates} 条` : '等待讲次'}</em></header>{selectedSession && <div className="alignment-content">{matching ? <div className="inline-loading"><Loader2 className="spin" size={18} />正在根据“{sessionItem?.title}”分析教学大纲…</div> : alignment?.matches.length ? <>{(['objective', 'knowledge', 'key_point', 'difficult_point', 'practice', 'assessment'] as SyllabusRequirementType[]).map((category) => { const items = alignment.matches.filter((item) => item.category === category); return items.length ? <div className="requirement-group" key={category}><h4>{requirementLabels[category]}<span>{items.length}</span></h4>{items.map((item) => <label key={item.id} className={selectedRequirements.includes(item.id) ? 'selected' : ''}><input type="checkbox" checked={selectedRequirements.includes(item.id)} onChange={() => toggle(selectedRequirements, item.id, setSelectedRequirements)} /><span><strong>{item.title}</strong><small>{item.content}</small><em>{Math.round(item.score * 100)}% · {item.reason}</em></span></label>)}</div> : null; })}<details className="matching-meta"><summary>查看匹配说明</summary><p>{alignment.model_used ? '已使用智能体语义判断并结合章节、关键词证据。' : '当前使用章节、关键词和文本相似度匹配。'}候选大纲共 {alignment.total_candidates} 条。</p></details></> : <p className="step-empty">没有找到可靠匹配。仍可继续选择教材，生成结果会标记“大纲依据缺失”。</p>}</div>}</section>

          <section className={`planning-step ${selectedSession ? 'is-open' : ''}`}><header><span>3</span><div><strong>确定教材知识范围</strong><small>按一级、二级、三级标题选择本次课需要覆盖的知识点</small></div><em>{selectedTextbook.length} 项</em></header>{selectedSession && <div className="textbook-tree">{scope?.textbook_outline.length ? scope.textbook_outline.map((item) => <label key={item.id} className={`level-${item.level} ${selectedTextbook.includes(item.id) ? 'selected' : ''}`}><input type="checkbox" checked={selectedTextbook.includes(item.id)} onChange={() => toggle(selectedTextbook, item.id, setSelectedTextbook)} /><span><strong>{item.title}</strong><small>{item.preview || `来源：${item.source_name}`}</small></span></label>) : <p className="step-empty">尚未识别到教材目录，请关联或导入教材文件。</p>}</div>}</section>

          <footer className="scope-actions"><div><strong>{sessionItem?.title || '尚未选择讲次'}</strong><span>已选 {selectedRequirements.length} 条大纲要求、{selectedTextbook.length} 个教材标题</span></div><button type="button" disabled={mutating || !selectedSession || (!selectedRequirements.length && !selectedTextbook.length)} onClick={() => void createOutline()}>{mutating ? <Loader2 className="spin" size={16} /> : <BookOpen size={16} />}生成知识大纲</button></footer>
        </>}
      </main>

      <aside className="outline-panel">
        <header><div><span>本次课成果</span><strong>知识大纲</strong><small>只定义要讲的知识点，不编排教学活动和讲解顺序</small></div>{outline && <select value={`${outline.id}:${outline.version}`} onChange={(event) => { const [id, version] = event.target.value.split(':'); selectOutline(outlines.find((item) => item.id === id && item.version === Number(version)) || null); }}>{outlines.slice().sort((a, b) => b.updated_at.localeCompare(a.updated_at)).map((item) => <option key={`${item.id}:${item.version}`} value={`${item.id}:${item.version}`}>v{item.version} · {item.title}</option>)}</select>}</header>
        {!outline ? <div className="outline-empty"><BookOpen size={28} /><strong>尚未生成知识大纲</strong><span>完成左侧范围规划后，结果会固定显示在这里。</span>{latest.length > 0 && <button type="button" onClick={() => selectOutline(latest[0])}>打开最近大纲</button>}</div> : <>
          <div className="outline-status"><span className={outline.status === 'confirmed' ? 'confirmed' : ''}>{outline.status === 'confirmed' ? '已确认' : '草稿'}</span><strong>第 {outline.version} 版</strong><small>{outline.change_summary}</small></div>
          <div className="outline-tools"><button type="button" onClick={() => setOutlineEditing((value) => !value)}><Edit3 size={15} />{outlineEditing ? '结束编辑' : '编辑大纲'}</button><button type="button" onClick={() => setRefineOpen((value) => !value)}><FilePlus2 size={15} />基于资料细化</button><button type="button" className="danger" onClick={() => setDialog({ mode: 'delete-outline', outline, allHistory: false })}><Trash2 size={15} />删除版本</button></div>
          {outlineEditing ? <div className="outline-editor"><label>大纲名称<input value={draftTitle} onChange={(event) => setDraftTitle(event.target.value)} /></label><div className="node-editor-list">{draftNodes.map((node, index) => <div key={node.id} className="node-editor-row"><select value={node.level} onChange={(event) => setDraftNodes((current) => current.map((item) => item.id === node.id ? { ...item, level: Number(event.target.value) } : item))}><option value={1}>一级</option><option value={2}>二级</option><option value={3}>三级</option></select><input value={node.title} onChange={(event) => setDraftNodes((current) => current.map((item) => item.id === node.id ? { ...item, title: event.target.value } : item))} /><div><label><input type="checkbox" checked={node.is_key_point} onChange={(event) => setDraftNodes((current) => current.map((item) => item.id === node.id ? { ...item, is_key_point: event.target.checked } : item))} />重点</label><label><input type="checkbox" checked={node.is_difficult_point} onChange={(event) => setDraftNodes((current) => current.map((item) => item.id === node.id ? { ...item, is_difficult_point: event.target.checked } : item))} />难点</label></div><span><button type="button" disabled={index === 0} onClick={() => setDraftNodes((current) => { const next = [...current]; [next[index - 1], next[index]] = [next[index], next[index - 1]]; return next; })}><ArrowUp size={14} /></button><button type="button" disabled={index === draftNodes.length - 1} onClick={() => setDraftNodes((current) => { const next = [...current]; [next[index + 1], next[index]] = [next[index], next[index + 1]]; return next; })}><ArrowDown size={14} /></button><button type="button" onClick={() => setDraftNodes((current) => current.filter((item) => item.id !== node.id))}><Trash2 size={14} /></button></span></div>)}</div><button type="button" className="add-node" onClick={() => setDraftNodes((current) => [...current, { id: crypto.randomUUID(), parent_id: null, level: 1, title: '新增知识点', description: '', is_key_point: false, is_difficult_point: false, teacher_note: '教师新增', evidence: [{ source_type: 'teacher', locator: '', quote: '教师新增知识点', label: '教师补充' }] }])}><Plus size={15} />新增知识点</button></div> : <div className="outline-tree"><h3>{outline.title}</h3>{draftNodes.map((node) => <article key={node.id} className={`level-${node.level}`}><div><strong>{node.title}</strong><span>{node.is_key_point && <em>重点</em>}{node.is_difficult_point && <em className="difficult">难点</em>}</span></div>{node.description && <p>{node.description}</p>}<details><summary>{node.evidence.length} 条来源依据</summary>{node.evidence.map((evidence, index) => <blockquote key={evidence.id || `${node.id}:${index}`}><b>{evidence.label || evidence.source_type}</b><span>{evidence.quote}</span><small>{evidence.locator}</small></blockquote>)}</details></article>)}</div>}
          {refineTask && refineTask.outline_id === outline.id && <section className={`refine-task-status is-${refineTask.status}`}><header><span>{refineTask.status === 'completed' ? <CheckCircle2 size={16} /> : refineTask.status === 'failed' ? <AlertCircle size={16} /> : <Loader2 className="spin" size={16} />}<strong>{refineTask.stage_label}</strong></span><time>{refineTask.elapsed_seconds} 秒</time></header><div className="refine-progress"><span style={{ width: `${refineTask.progress}%` }} /></div><footer><span>{refineTask.progress}%</span><small>{refineTask.status === 'completed' ? `结果：第 ${refineTask.result_version} 版` : refineTask.status === 'failed' ? refineTask.error : '任务由后端持续执行，切换页面不会中断'}</small></footer></section>}
          {refineOpen && <section className="refine-panel"><header><strong>在已选范围内细化</strong><button type="button" onClick={() => setRefineOpen(false)} aria-label="关闭细化面板"><X size={15} /></button></header><p>当前大纲是固定边界。所选资料只用于补充现有知识点的下级内容和原文依据，不会加入未选择的章节。</p><div>{availableFiles.map((file) => <label key={file.material_id}><input type="checkbox" checked={refineMaterials.includes(file.material_id)} onChange={() => toggle(refineMaterials, file.material_id, setRefineMaterials)} /><span><strong>{file.name}</strong><small>{file.sourceLabel}</small></span></label>)}</div><textarea value={refineInstruction} onChange={(event) => setRefineInstruction(event.target.value)} placeholder="例如：细化当前知识点的概念、边界条件与公式含义，不扩展到其他章节。" /><button type="button" disabled={mutating || Boolean(refineTask && !['completed', 'failed'].includes(refineTask.status)) || !refineMaterials.length || refineInstruction.trim().length < 2} onClick={() => void refineOutline()}>{mutating ? <Loader2 className="spin" size={15} /> : <FileSearch size={15} />}生成范围内细化版本</button></section>}
          <footer className="outline-actions"><button type="button" disabled={mutating || !draftNodes.length} onClick={() => void saveOutlineVersion('draft')}><Save size={15} />保存新版本</button><button type="button" disabled={mutating || !draftNodes.length} onClick={() => void saveOutlineVersion('confirmed')}><CheckCircle2 size={15} />确认知识范围</button><button type="button" className="primary" disabled={mutating} onClick={() => { const textbookIds = designImportFiles.filter((file) => file.category === 'textbook').map((file) => file.material_id); setDialog({ mode: 'import-design', outlineKey: `${outline.id}:${outline.version}`, materialIds: textbookIds, primaryMaterialId: textbookIds[0] || '' }); }}><Send size={15} />导入课程设计</button></footer>
        </>}
      </aside>
    </div>}
    {dialog && <UnitDialog dialog={dialog} units={units} files={designImportFiles} outlines={outlines} mutating={mutating} onChange={setDialog} onClose={() => setDialog(null)} onSubmit={() => void submitDialog()} />}
    {previewFile && <FilePreview file={previewFile} onClose={() => setPreviewFile(null)} />}
  </div>;
}

function UnitDialog({ dialog, units, files, outlines, mutating, onChange, onClose, onSubmit }: { dialog: Dialog; units: MaterialUnitSummary[]; files: Array<MaterialUnitFileAnalysis & { sourceLabel: string }>; outlines: MaterialUnitKnowledgeOutline[]; mutating: boolean; onChange: (dialog: Dialog) => void; onClose: () => void; onSubmit: () => void }) {
  const target = dialog.mode === 'merge' || dialog.mode === 'link-files' ? dialog.target : dialog.mode === 'rename' || dialog.mode === 'delete' ? dialog.unit : null;
  const sources = target ? units.filter((item) => item.id !== target.id) : [];
  const selectedImportOutline = dialog.mode === 'import-design' ? outlines.find((item) => `${item.id}:${item.version}` === dialog.outlineKey) : null;
  const importFiles = files;
  const selectedImportFiles = dialog.mode === 'import-design' ? files.filter((file) => dialog.materialIds.includes(file.material_id)) : [];
  const primaryImportFile = dialog.mode === 'import-design' ? files.find((file) => file.material_id === dialog.primaryMaterialId) : null;
  const [sourceRecord, setSourceRecord] = useState<MaterialUnitRecord | null>(null);
  useEffect(() => { if (dialog.mode === 'link-files' && dialog.sourceUnitId) void materialUnitApi.get(dialog.sourceUnitId).then(setSourceRecord); else setSourceRecord(null); }, [dialog]);
  return <div className="unit-dialog-backdrop"><section className={`unit-dialog ${dialog.mode === 'import-design' ? 'is-wide' : ''}`} role="dialog" aria-modal="true"><header><div>{dialog.mode === 'merge' ? <GitMerge size={19} /> : dialog.mode === 'link-files' ? <Link2 size={19} /> : dialog.mode === 'delete' || dialog.mode === 'delete-outline' ? <Trash2 size={19} /> : dialog.mode === 'import-design' ? <Send size={19} /> : <Edit3 size={19} />}<span><strong>{dialog.mode === 'merge' ? '整合为一个单元' : dialog.mode === 'link-files' ? '关联其他单元资料' : dialog.mode === 'delete' ? '删除资料单元' : dialog.mode === 'delete-outline' ? '删除知识大纲' : dialog.mode === 'import-design' ? '确认导入课程设计' : '重命名资料单元'}</strong><small>{dialog.mode === 'merge' ? '来源单元会从列表移除，课程资料库原文件不会删除' : dialog.mode === 'link-files' ? '只建立文件引用，来源单元和原文件保持不变' : dialog.mode === 'delete' ? '只删除资料单元记录，不删除课程资料库原文件' : dialog.mode === 'delete-outline' ? '删除操作不会影响教材、进度表和教学大纲原文件' : dialog.mode === 'import-design' ? '请核对知识大纲版本、主教材和支撑资料后再导入' : '资料关系和分析结果保持不变'}</small></span></div><button type="button" onClick={onClose} aria-label="关闭"><X size={17} /></button></header>
    {dialog.mode === 'rename' && <label>单元名称<input autoFocus value={dialog.title} onChange={(event) => onChange({ ...dialog, title: event.target.value })} /></label>}
    {dialog.mode === 'delete' && target && <div className="dialog-warning"><strong>确认删除“{target.title}”？</strong><span>知识大纲和单元内整理关系会一并删除，但课程资料库和本机原文件不会删除。</span></div>}
    {dialog.mode === 'delete-outline' && <><div className="dialog-warning"><strong>{dialog.outline.title} · 第 {dialog.outline.version} 版</strong><span>{dialog.allHistory ? '将删除该知识大纲的全部历史版本。' : '只删除当前选中的历史版本；若它是最新版，上一版本将成为最新版。'}</span></div><label className="delete-history-option"><input type="checkbox" checked={dialog.allHistory} onChange={(event) => onChange({ ...dialog, allHistory: event.target.checked })} /><span><b>删除全部历史版本</b><small>课程设计正在引用的版本受保护，无法删除</small></span></label></>}
    {dialog.mode === 'import-design' && <div className="import-confirm-grid"><section><label>知识大纲版本<select value={dialog.outlineKey} onChange={(event) => onChange({ ...dialog, outlineKey: event.target.value })}>{outlines.slice().sort((a, b) => b.updated_at.localeCompare(a.updated_at)).map((item) => <option key={`${item.id}:${item.version}`} value={`${item.id}:${item.version}`}>v{item.version} · {item.title} · {item.nodes.length} 个知识点</option>)}</select></label><div className="import-outline-summary"><BookOpen size={18} /><span><strong>{selectedImportOutline?.title}</strong><small>第 {selectedImportOutline?.version} 版 · {selectedImportOutline?.status === 'confirmed' ? '已确认' : '草稿'} · {selectedImportOutline?.nodes.length || 0} 个知识点</small></span></div></section><section><div className="dialog-section-title"><strong>教材与支撑资料</strong><span>已选 {dialog.materialIds.length} 份</span></div><div className="dialog-options import-files">{importFiles.map((file) => <label key={file.material_id} className={dialog.materialIds.includes(file.material_id) ? 'selected' : ''}><input type="checkbox" checked={dialog.materialIds.includes(file.material_id)} onChange={() => { const next = dialog.materialIds.includes(file.material_id) ? dialog.materialIds.filter((id) => id !== file.material_id) : [...dialog.materialIds, file.material_id]; const primary = next.includes(dialog.primaryMaterialId) ? dialog.primaryMaterialId : (files.find((item) => next.includes(item.material_id) && item.category === 'textbook')?.material_id || ''); onChange({ ...dialog, materialIds: next, primaryMaterialId: primary }); }} /><span><b>{file.name}</b><small>{categoryLabels[file.category] || file.category} · {file.character_count.toLocaleString()} 字 · {file.quality_level || file.parse_status} · {file.sourceLabel}</small></span></label>)}</div><label>主教材<select value={dialog.primaryMaterialId} onChange={(event) => onChange({ ...dialog, primaryMaterialId: event.target.value })}><option value="">请选择主教材</option>{selectedImportFiles.filter((file) => file.category === 'textbook').map((file) => <option key={file.material_id} value={file.material_id}>{file.name}</option>)}</select></label></section><aside><strong>导入摘要</strong><span>知识大纲 v{selectedImportOutline?.version || '-'}</span><span>{selectedImportOutline?.nodes.length || 0} 个知识点</span><span>{selectedImportFiles.filter((file) => file.category === 'textbook').length} 份教材</span><span>{selectedImportFiles.filter((file) => file.category !== 'textbook').length} 份支撑资料</span><small>{primaryImportFile ? `主教材：${primaryImportFile.name}` : '尚未指定主教材'}</small></aside></div>}
    {dialog.mode === 'merge' && <><label>整合后的名称<input value={dialog.title} onChange={(event) => onChange({ ...dialog, title: event.target.value })} /></label><div className="dialog-options"><strong>选择要整合的单元</strong>{sources.map((source) => <label key={source.id}><input type="checkbox" checked={dialog.sourceIds.includes(source.id)} onChange={() => onChange({ ...dialog, sourceIds: dialog.sourceIds.includes(source.id) ? dialog.sourceIds.filter((id) => id !== source.id) : [...dialog.sourceIds, source.id] })} /><span><b>{source.title}</b><small>{source.material_count} 份资料；整合后该单元会从列表移除</small></span></label>)}</div>{dialog.sourceIds.length > 0 && <div className="merge-impact"><strong>将发生以下变化</strong><span>当前单元与 {dialog.sourceIds.length} 个来源单元整合为“{dialog.title || dialog.target.title}”</span><span>{dialog.sourceIds.length} 个来源单元将从单元列表移除</span><span>课程资料库中的原始文件不会删除</span></div>}</>}
    {dialog.mode === 'link-files' && <><label>来源单元<select value={dialog.sourceUnitId} onChange={(event) => onChange({ ...dialog, sourceUnitId: event.target.value, materialIds: [] })}><option value="">请选择来源单元</option>{sources.map((source) => <option key={source.id} value={source.id}>{source.title}</option>)}</select></label>{sourceRecord && <div className="dialog-options"><strong>选择要关联的文件</strong>{sourceRecord.files.map((file) => <label key={file.material_id}><input type="checkbox" checked={dialog.materialIds.includes(file.material_id)} onChange={() => onChange({ ...dialog, materialIds: dialog.materialIds.includes(file.material_id) ? dialog.materialIds.filter((id) => id !== file.material_id) : [...dialog.materialIds, file.material_id] })} /><span><b>{file.name}</b><small>{categoryLabels[file.category] || file.category} · 关联后可用于匹配和细化</small></span></label>)}</div>}</>}
    <footer><button type="button" onClick={onClose}>取消</button><button type="button" className={dialog.mode === 'delete' || dialog.mode === 'delete-outline' ? 'danger' : 'primary'} disabled={mutating || (dialog.mode === 'rename' && !dialog.title.trim()) || (dialog.mode === 'merge' && !dialog.sourceIds.length) || (dialog.mode === 'link-files' && (!dialog.sourceUnitId || !dialog.materialIds.length)) || (dialog.mode === 'import-design' && (!dialog.outlineKey || !dialog.materialIds.length || !dialog.primaryMaterialId || primaryImportFile?.category !== 'textbook'))} onClick={onSubmit}>{mutating ? <Loader2 className="spin" size={15} /> : <Check size={15} />}{dialog.mode === 'merge' ? '确认整合' : dialog.mode === 'link-files' ? '确认关联' : dialog.mode === 'delete' || dialog.mode === 'delete-outline' ? '确认删除' : dialog.mode === 'import-design' ? '确认并进入课程设计' : '保存名称'}</button></footer>
  </section></div>;
}

function FilePreview({ file, onClose }: { file: MaterialUnitFileAnalysis; onClose: () => void }) {
  return <div className="file-preview-backdrop"><aside className="file-preview-drawer"><header><div><span>{categoryLabels[file.category] || file.category}</span><strong>{file.name}</strong><small>{file.path}</small></div><button type="button" onClick={onClose}><X size={17} /></button></header><section><h3>保存的文件分析</h3><p>{file.summary || file.parse_message || '暂无摘要'}</p><dl><div><dt>解析引擎</dt><dd>{file.extraction_engine || '未执行'}</dd></div><div><dt>识别质量</dt><dd>{file.quality_level || '未评估'}</dd></div><div><dt>内容规模</dt><dd>{file.character_count.toLocaleString()} 字 · {file.section_count} 个分区</dd></div></dl>{file.knowledge_points.length > 0 && <div className="file-points">{file.knowledge_points.map((point) => <span key={point}>{point}</span>)}</div>}</section><footer>{file.document_id && file.preview_available && <button type="button" onClick={() => window.open(documentApi.previewUrl(file.document_id!), '_blank', 'noopener,noreferrer')}><ExternalLink size={15} />打开原页预览</button>}</footer></aside></div>;
}
