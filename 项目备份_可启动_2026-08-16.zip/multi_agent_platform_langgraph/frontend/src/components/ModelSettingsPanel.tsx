import { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock3,
  Eye,
  EyeOff,
  History,
  Loader2,
  PlugZap,
  RefreshCw,
  Save,
  Settings2,
  ShieldCheck,
  X,
} from 'lucide-react';
import { getErrorMessage, modelSettingsApi } from '../lib/api';
import type {
  ModelDiscoveryResult,
  ModelHistoryItem,
  ModelSettingsInput,
  ModelSettings,
  ModelTestResult,
} from '../types/workflow';

interface Props { onClose: () => void; onSaved: () => void; }

const emptyForm: ModelSettingsInput = {
  provider: 'mock',
  base_url: 'https://api.openai.com/v1',
  model: 'deterministic-mock',
  api_key: '',
  temperature: 0.2,
  timeout_seconds: 90,
};

const mockModels = ['deterministic-mock', 'mock-teaching', 'mock-fast'];

function normalizeUrl(value: string): string {
  return value.trim().replace(/\/+$/, '');
}

function formatHistoryDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function getProviderLabel(provider: ModelHistoryItem['provider']): string {
  return provider === 'mock' ? '本地演示' : 'OpenAI 兼容';
}

export function ModelSettingsPanel({ onClose, onSaved }: Props) {
  const [form, setForm] = useState<ModelSettingsInput>(emptyForm);
  const [history, setHistory] = useState<ModelHistoryItem[]>([]);
  const [hasKey, setHasKey] = useState(false);
  const [savedEndpoint, setSavedEndpoint] = useState<Pick<ModelSettings, 'provider' | 'base_url'> | null>(null);
  const [showKey, setShowKey] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<'discover' | 'test' | 'save' | null>(null);
  const [discovery, setDiscovery] = useState<ModelDiscoveryResult | null>(null);
  const [result, setResult] = useState<ModelTestResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const visibleHistory = useMemo(
    () => history.filter((item, index, items) => items.findIndex((other) => (
      other.provider === item.provider
      && other.model === item.model
      && (item.provider === 'mock' || other.base_url === item.base_url)
    )) === index).slice(0, 6),
    [history],
  );

  useEffect(() => {
    let active = true;
    Promise.all([modelSettingsApi.get(), modelSettingsApi.history()])
      .then(([value, items]) => {
        if (!active) return;
        setForm({
          provider: value.provider,
          base_url: value.base_url,
          model: value.model,
          temperature: value.temperature,
          timeout_seconds: value.timeout_seconds,
          api_key: '',
        });
        setHistory(items);
        setHasKey(value.has_api_key);
        setSavedEndpoint({ provider: value.provider, base_url: value.base_url });
      })
      .catch((reason) => { if (active) setError(getErrorMessage(reason)); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const update = <K extends keyof ModelSettingsInput>(key: K, value: ModelSettingsInput[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
    if (key === 'provider' || key === 'base_url' || key === 'api_key') setDiscovery(null);
    setResult(null);
    setError(null);
  };

  const changeProvider = (provider: ModelSettingsInput['provider']) => {
    setForm((current) => ({
      ...current,
      provider,
      model: provider === 'mock' ? 'deterministic-mock' : mockModels.includes(current.model) ? 'gpt-4.1-mini' : current.model,
      api_key: provider === 'mock' ? '' : current.api_key,
    }));
    setDiscovery(null);
    setResult(null);
    setError(null);
  };

  const applyHistory = (item: ModelHistoryItem) => {
    setForm((current) => ({
      ...current,
      provider: item.provider,
      base_url: item.base_url,
      model: item.model,
      api_key: '',
    }));
    setDiscovery(null);
    setResult(null);
    setError(null);
  };

  const savedKeyCanBeRetained = Boolean(
    hasKey
      && savedEndpoint
      && form.provider === savedEndpoint.provider
      && normalizeUrl(form.base_url) === normalizeUrl(savedEndpoint.base_url),
  );

  const discover = async () => {
    setBusy('discover');
    setError(null);
    setResult(null);
    setDiscovery(null);
    try {
      setDiscovery(await modelSettingsApi.discover(form));
    } catch (reason) {
      setError(getErrorMessage(reason));
    } finally {
      setBusy(null);
    }
  };

  const test = async () => {
    setBusy('test');
    setError(null);
    setResult(null);
    try {
      setResult(await modelSettingsApi.test(form));
    } catch (reason) {
      setError(getErrorMessage(reason));
    } finally {
      setBusy(null);
    }
  };

  const save = async () => {
    setBusy('save');
    setError(null);
    try {
      const saved = await modelSettingsApi.update(form);
      setHasKey(saved.has_api_key);
      setForm((current) => ({ ...current, api_key: '' }));
      onSaved();
      onClose();
    } catch (reason) {
      setError(getErrorMessage(reason));
    } finally {
      setBusy(null);
    }
  };

  const connectionState = discovery ? (discovery.ok ? 'connected' : 'failed') : 'idle';
  const selectedDiscoveredModel = discovery?.ok && discovery.models.includes(form.model) ? form.model : '';

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section className="settings-dialog" role="dialog" aria-modal="true" aria-labelledby="settings-title">
        <header className="dialog-header">
          <div className="dialog-title">
            <span className="dialog-icon"><Settings2 size={18} /></span>
            <div><h2 id="settings-title">模型服务设置</h2><p>选择模型、探测接口并保留最近使用记录</p></div>
          </div>
          <button className="icon-button" type="button" onClick={onClose} title="关闭设置" aria-label="关闭设置"><X size={17} /></button>
        </header>
        {loading ? <div className="settings-loading"><Loader2 className="spin" size={20} />正在读取配置</div> : (
          <div className="settings-body">
            <section className="settings-section settings-connection">
              <div className="settings-section-heading">
                <div><strong>连接来源</strong><small>先确认接口可达，再从返回列表中选择模型</small></div>
                <span className={`connection-state ${connectionState}`}>
                  {connectionState === 'connected' && <CheckCircle2 size={13} />}
                  {connectionState === 'failed' && <AlertCircle size={13} />}
                  {connectionState === 'idle' && <PlugZap size={13} />}
                  {connectionState === 'connected' ? '已连接' : connectionState === 'failed' ? '连接失败' : '未检测'}
                </span>
              </div>
              <div className="field-group">
                <span className="field-label">服务类型</span>
                <div className="provider-control">
                  <button type="button" className={form.provider === 'mock' ? 'active' : ''} onClick={() => changeProvider('mock')}>本地演示模型</button>
                  <button type="button" className={form.provider === 'openai_compatible' ? 'active' : ''} onClick={() => changeProvider('openai_compatible')}>OpenAI 兼容接口</button>
                </div>
              </div>
              <div className="endpoint-row">
                <label className="field-group"><span className="field-label">接口地址</span><input value={form.base_url} onChange={(event) => update('base_url', event.target.value)} disabled={form.provider === 'mock'} placeholder="https://api.openai.com/v1" /></label>
                <button className="secondary-button discover-button" type="button" onClick={() => void discover()} disabled={Boolean(busy) || loading}>
                  {busy === 'discover' ? <Loader2 className="spin" size={15} /> : <RefreshCw size={15} />}
                  {busy === 'discover' ? '连接中' : form.provider === 'mock' ? '查看模型' : '连接并获取模型'}
                </button>
              </div>
              {discovery && <div className={`discovery-meta ${discovery.ok ? 'ok' : 'failed'}`}><span>{discovery.message}</span><small>{discovery.latency_ms} ms</small></div>}
            </section>

            <section className="settings-section">
              <div className="settings-section-heading"><div><strong>模型选择</strong><small>可选择接口发现的模型，也可以手动输入名称</small></div><span className="model-count">{discovery?.ok ? `${discovery.models.length} 个可用` : '等待连接'}</span></div>
              <div className="model-picker">
                <select value={selectedDiscoveredModel} onChange={(event) => event.target.value && update('model', event.target.value)} disabled={!discovery?.ok || Boolean(busy)} aria-label="选择已发现的模型">
                  <option value="">从接口返回列表中选择</option>
                  {discovery?.models.map((model) => <option key={model} value={model}>{model}</option>)}
                </select>
                <label className="field-group"><span className="field-label">当前模型</span><input value={form.model} onChange={(event) => update('model', event.target.value)} placeholder="例如 gpt-4.1-mini" /></label>
              </div>
              {discovery?.ok && discovery.models.length > 0 && !selectedDiscoveredModel && <p className="field-hint">当前输入的模型不在本次返回列表中，保存前请确认名称。</p>}
            </section>

            <label className="field-group">
              <span className="field-label">API Key <small>{form.provider === 'mock' ? '本地演示无需密钥' : savedKeyCanBeRetained ? '已配置，留空将保留原值' : form.api_key ? '将仅保存到本机后端' : '请输入此接口对应的 API Key'}</small></span>
              <span className="secret-input"><input type={showKey ? 'text' : 'password'} value={form.api_key} onChange={(event) => update('api_key', event.target.value)} disabled={form.provider === 'mock'} placeholder={savedKeyCanBeRetained ? '••••••••••••••••' : '输入 API Key'} /><button type="button" onClick={() => setShowKey((value) => !value)} disabled={form.provider === 'mock'} title={showKey ? '隐藏' : '显示'} aria-label={showKey ? '隐藏 API Key' : '显示 API Key'}>{showKey ? <EyeOff size={16} /> : <Eye size={16} />}</button></span>
            </label>

            <section className="settings-section history-section">
              <div className="settings-section-heading"><div><strong><History size={14} />最近使用</strong><small>只保存供应商、地址和模型名，不保存 API Key</small></div><span className="model-count">{history.length}/20</span></div>
              {visibleHistory.length > 0 ? <div className="model-history-list">
                {visibleHistory.map((item) => <button className="model-history-item" type="button" key={`${item.provider}-${item.base_url}-${item.model}`} onClick={() => applyHistory(item)} title={`使用 ${item.model}`}>
                  <span className="history-item-main"><strong translate="no">{item.model}</strong><small translate="no">{item.provider === 'mock' ? '本地演示服务 · 无需 API Key' : `${getProviderLabel(item.provider)} · ${item.base_url}`}</small></span>
                  <span className="history-item-meta"><small>{item.use_count} 次</small><small>{formatHistoryDate(item.last_used_at)}</small></span>
                  {item.has_api_key && <ShieldCheck size={14} aria-label="该模型最近使用时已配置密钥" />}
                </button>)}
              </div> : <div className="history-empty"><Clock3 size={15} /><span>保存模型后，会在这里快速切换</span></div>}
            </section>

            <div className="settings-grid">
              <label className="field-group"><span className="field-label">温度 <strong>{form.temperature.toFixed(1)}</strong></span><input type="range" min="0" max="2" step="0.1" value={form.temperature} onChange={(event) => update('temperature', Number(event.target.value))} /></label>
              <label className="field-group"><span className="field-label">超时时间（秒）</span><input type="number" min="5" max="600" value={form.timeout_seconds} onChange={(event) => update('timeout_seconds', Number(event.target.value))} /></label>
            </div>
            {result && <div className={`test-result ${result.ok ? 'success' : 'error'}`}>{result.ok ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}<span>{result.message}</span><small>{result.model} · {result.latency_ms} ms</small></div>}
            {error && <div className="test-result error"><AlertCircle size={16} /><span>{error}</span></div>}
          </div>
        )}
        <footer className="dialog-footer">
          <button className="secondary-button" type="button" onClick={() => void test()} disabled={Boolean(busy) || loading}><PlugZap size={15} />{busy === 'test' ? '检测中' : '测试连接'}</button>
          <button className="primary-button compact" type="button" onClick={() => void save()} disabled={Boolean(busy) || loading}><Save size={15} />{busy === 'save' ? '保存中' : '保存并应用'}</button>
        </footer>
      </section>
    </div>
  );
}
