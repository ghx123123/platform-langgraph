@echo off
chcp 65001 >nul
echo Multi-Agent Studio port status
echo.
powershell -NoProfile -Command "$ports=8000,5173; foreach($port in $ports){$listener=Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue; if($listener){Write-Host ($port.ToString() + ' LISTENING PID=' + $listener[0].OwningProcess)}else{Write-Host ($port.ToString() + ' AVAILABLE')}}"
