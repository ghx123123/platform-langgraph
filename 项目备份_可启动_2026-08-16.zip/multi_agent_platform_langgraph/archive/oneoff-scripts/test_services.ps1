# Multi-Agent Platform Test Script
$ErrorActionPreference = "SilentlyContinue"

Write-Host "========================================"
Write-Host "  Testing Port Management"
Write-Host "========================================"
Write-Host ""

$PROJECT_DIR = "D:\paper\cc\projects\multi_agent_platform"
$BACKEND_PORT = 8000
$FRONTEND_PORT = 3000

Write-Host "Project: $PROJECT_DIR"
Write-Host "Backend Port: $BACKEND_PORT"
Write-Host "Frontend Port: $FRONTEND_PORT"
Write-Host ""

# Step 1: Clean up existing processes and windows
Write-Host "[1/4] Cleaning up existing processes..."

# Kill MAP windows
taskkill /F /FI "WINDOWTITLE eq MAP-*" 2>$null

# Get processes on ports
$backendPids = Get-NetTCPConnection -LocalPort $BACKEND_PORT | Select-Object -ExpandProperty OwningProcess -Unique
$frontendPids = Get-NetTCPConnection -LocalPort $FRONTEND_PORT | Select-Object -ExpandProperty OwningProcess -Unique

foreach ($pid in $backendPids) {
    Write-Host "  Killing backend PID: $pid"
    Stop-Process -Id $pid -Force
}

foreach ($pid in $frontendPids) {
    Write-Host "  Killing frontend PID: $pid"
    Stop-Process -Id $pid -Force
}

Start-Sleep -Seconds 2

# Step 2: Verify ports are free
Write-Host ""
Write-Host "[2/4] Verifying ports are free..."

$stillOn8000 = Get-NetTCPConnection -LocalPort $BACKEND_PORT -State Listen
$stillOn3000 = Get-NetTCPConnection -LocalPort $FRONTEND_PORT -State Listen

if ($stillOn8000) {
    Write-Host "  [WARNING] Port $BACKEND_PORT still in use"
} else {
    Write-Host "  [OK] Port $BACKEND_PORT is free"
}

if ($stillOn3000) {
    Write-Host "  [WARNING] Port $FRONTEND_PORT still in use"
} else {
    Write-Host "  [OK] Port $FRONTEND_PORT is free"
}

# Step 3: Start services
Write-Host ""
Write-Host "[3/4] Starting services..."

# Start backend
$backendJob = Start-Process -FilePath "cmd.exe" -ArgumentList "/c","cd /d $PROJECT_DIR\backend && python -m uvicorn main:app --reload --host 0.0.0.0 --port $BACKEND_PORT" -PassThru -WindowStyle Hidden

Write-Host "  Backend starting on port $BACKEND_PORT (PID: $($backendJob.Id))"

# Wait for backend
Start-Sleep -Seconds 5

# Start frontend
$frontendJob = Start-Process -FilePath "cmd.exe" -ArgumentList "/c","cd /d $PROJECT_DIR\frontend && npm run dev -- --port $FRONTEND_PORT" -PassThru -WindowStyle Hidden

Write-Host "  Frontend starting on port $FRONTEND_PORT (PID: $($frontendJob.Id))"

# Wait for frontend
Start-Sleep -Seconds 5

# Step 4: Verify services are running
Write-Host ""
Write-Host "[4/4] Verifying services..."

$backendCheck = Invoke-WebRequest -Uri "http://127.0.0.1:$BACKEND_PORT/health" -TimeoutSec 5 -ErrorAction SilentlyContinue
$frontendCheck = Invoke-WebRequest -Uri "http://localhost:$FRONTEND_PORT" -TimeoutSec 5 -ErrorAction SilentlyContinue

if ($backendCheck) {
    Write-Host "  [OK] Backend running on port $BACKEND_PORT"
} else {
    Write-Host "  [WARNING] Backend not responding on port $BACKEND_PORT"
}

if ($frontendCheck) {
    Write-Host "  [OK] Frontend running on port $FRONTEND_PORT"
} else {
    Write-Host "  [WARNING] Frontend not responding on port $FRONTEND_PORT"
}

# Show listening ports
Write-Host ""
Write-Host "Current listening ports:"
Get-NetTCPConnection -LocalPort $BACKEND_PORT,$FRONTEND_PORT -State Listen | Format-Table -AutoSize

Write-Host ""
Write-Host "Done."