@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title Multi-Agent Platform - Tests

echo ========================================
echo   Running Backend Tests
echo ========================================
echo.

REM Get project directory
set "PROJECT_DIR=%~dp0"
set "PROJECT_DIR=%PROJECT_DIR:~0,-1%"

REM Activate venv and run tests
if exist "%PROJECT_DIR%\backend\venv\Scripts\activate.bat" (
    call "%PROJECT_DIR%\backend\venv\Scripts\activate.bat"
    echo Running all tests with virtual environment...
    python -m pytest tests/ -v --tb=short
) else (
    echo [警告] 虚拟环境未找到，尝试使用系统 Python...
    python -m pytest tests/ -v --tb=short
    if errorlevel 1 (
        echo [错误] 测试失败，请确保已安装依赖
        pause
        exit /b 1
    )
)

echo.
echo ========================================
echo   Tests Complete
echo ========================================
echo.
pause
