# Test Script for Multi-Agent Platform
param(
    [int]$BackendPort = 8000,
    [int]$FrontendPort = 3000
)

$PROJECT_DIR = "D:\paper\cc\projects\multi_agent_platform"
$ErrorActionPreference = "Continue"

function Write-Header($text) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step($step, $total, $text) {
    Write-Host "[$step/$total] $text" -ForegroundColor Yellow
}

function Write-OK($text) {
    Write-Host "  [OK] $text" -ForegroundColor Green
}

function Write-Error($text) {
    Write-Host "  [Error] $text" -ForegroundColor Red
}

# Step 1: Clean existing processes
Write-Step 1 3 "Cleaning existing processes..."

taskkill /F /FI "WINDOWTITLE eq MAP-Frontend*" 2>$null | Out-Null
taskkill /F /FI "WINDOWTITLE eq MAP-Backend*" 2>$null | Out-Null

Get-NetTCPConnection -LocalPort $BackendPort -ErrorAction SilentlyContinue | 
    ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
Get-NetTCPConnection -LocalPort $FrontendPort -ErrorAction SilentlyContinue | 
    ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }

Start-Sleep -Seconds 2
Write-OK "Cleaned"
Write-Host ""

# Step 2: Start backend
Write-Step 2 3 "Starting backend service..."
Write-Host "  URL: http://localhost:$BackendPort"
Write-Host ""

Set-Location $PROJECT_DIR

# Detect Python
$PYTHON_CMD = $null
if (Test-Path "backend\venv\Scripts\python.exe") {
    $PYTHON_CMD = "backend\venv\Scripts\python.exe"
    Write-OK "Using venv Python"
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $PYTHON_CMD = "python"
    Write-OK "Using system Python"
} else {
    Write-Error "Python not found"
    exit 1
}

# Start backend (minimized)
$backendJob = Start-Process -FilePath "cmd" -ArgumentList "/c cd /d $PROJECT_DIR && $PYTHON_CMD -m uvicorn backend.app:app --host 0.0.0.0 --port $BackendPort" -PassThru -WindowStyle Minimized
Write-OK "Backend process started (PID: $($backendJob.Id))"

# Wait for backend
Write-Host "  Waiting for backend..."
$retry = 0
$backendReady = $false
while ($retry -lt 30 -and -not $backendReady) {
    Start-Sleep -Seconds 1
    $retry++
    try {
        $response = Invoke-WebRequest -Uri "http://127.0.0.1:$BackendPort/health" -TimeoutSec 1 -ErrorAction SilentlyContinue
        if ($response.StatusCode -eq 200) {
            $backendReady = $true
            Write-OK "Backend ready"
        }
    } catch {}
}
if (-not $backendReady) {
    Write-Error "Backend timeout, continuing..."
}
Write-Host ""

# Step 3: Start frontend
Write-Step 3 3 "Starting frontend service..."
Write-Host "  URL: http://localhost:$FrontendPort"
Write-Host ""

# Check dependencies
if (-not (Test-Path "$PROJECT_DIR\frontend\node_modules")) {
    Write-Host "  Installing frontend dependencies..."
    Set-Location "$PROJECT_DIR\frontend"
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Frontend install failed"
        exit 1
    }
    Set-Location $PROJECT_DIR
}

# Start frontend (visible window)
Set-Location "$PROJECT_DIR\frontend"
$frontendJob = Start-Process -FilePath "cmd" -ArgumentList "/k npm run dev -- --port $FrontendPort" -PassThru
Write-OK "Frontend process started (PID: $($frontendJob.Id))"
Set-Location $PROJECT_DIR

# Wait for frontend
Write-Host "  Waiting for frontend..."
Start-Sleep -Seconds 3

Write-Header "Platform Started!"
Write-Host "  Frontend: http://localhost:$FrontendPort"
Write-Host "  Backend: http://localhost:$BackendPort"
Write-Host ""
Write-Host "  Tip: Close frontend CMD window to stop platform" -ForegroundColor Magenta
Write-Host ""

# Monitor loop
Write-Host "[Monitor] Running, press Ctrl+C to stop..." -ForegroundColor Cyan
Write-Host ""

try {
    while ($true) {
        # Check if frontend process is still running
        $frontendProcess = Get-Process -Id $frontendJob.Id -ErrorAction SilentlyContinue
        if (-not $frontendProcess) {
            Write-Host ""
            Write-Host "[Monitor] Frontend closed, stopping backend..." -ForegroundColor Yellow
            
            # Stop backend
            Stop-Process -Id $backendJob.Id -Force -ErrorAction SilentlyContinue
            
            # Clean ports
            Get-NetTCPConnection -LocalPort $BackendPort -ErrorAction SilentlyContinue | 
                ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
            Get-NetTCPConnection -LocalPort $FrontendPort -ErrorAction SilentlyContinue | 
                ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
            
            # Clean node and uvicorn
            Get-Process -Name "node" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            Get-Process | Where-Object {$_.CommandLine -like "*uvicorn*"} | Stop-Process -Force -ErrorAction SilentlyContinue
            
            Write-OK "Backend stopped"
            Write-Header "Platform Closed"
            break
        }
        
        Start-Sleep -Seconds 1
    }
} catch {
    Write-Host ""
    Write-Host "[Monitor] Interrupted by user" -ForegroundColor Yellow
    
    # Cleanup
    Stop-Process -Id $frontendJob.Id -Force -ErrorAction SilentlyContinue
    Stop-Process -Id $backendJob.Id -Force -ErrorAction SilentlyContinue
    
    Write-OK "Platform stopped"
}
