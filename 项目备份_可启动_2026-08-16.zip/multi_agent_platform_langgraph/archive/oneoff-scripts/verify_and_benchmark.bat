@echo off
chcp 65001 >nul
title Multi-Agent Platform Verification

echo ========================================
echo   Multi-Agent Platform 验证脚本
echo ========================================
echo.

set "PROJECT_DIR=%~dp0"
set "PROJECT_DIR=%PROJECT_DIR:~0,-1%"

REM Kill any existing processes on our ports
echo [清理] 停止已有服务...
netstat -ano | findstr :8000 | findstr LISTENING >nul && (echo Port 8000 is already in use. & exit /b 1)
netstat -ano | findstr :5173 | findstr LISTENING >nul && (echo Port 5173 is already in use. & exit /b 1)

REM ============================================================================
REM Start Backend
REM ============================================================================
echo [启动] 后端服务 (http://localhost:8000)...
start "MAP-Backend" cmd /k "cd /d %PROJECT_DIR% && python -m uvicorn backend.app:app --host 0.0.0.0 --port 8000"

REM Wait for backend to be ready
echo [等待] 后端启动...
:wait_backend
curl -s http://localhost:8000/health >nul 2>&1
if errorlevel 1 (
    timeout /t 1 /nobreak >nul
    goto wait_backend
)
echo [OK] 后端运行正常

REM ============================================================================
REM Start Frontend
REM ============================================================================
echo [启动] 前端服务 (http://localhost:5173)...
start "MAP-Frontend" cmd /k "cd /d %PROJECT_DIR%\frontend && npm run dev"

echo [等待] 前端启动...
timeout /t 5 /nobreak >nul

REM ============================================================================
REM Open Browser
REM ============================================================================
echo [打开] 浏览器...
start http://localhost:5173

echo.
echo ========================================
echo   服务已启动，请访问: http://localhost:5173
echo ========================================
echo.
echo   后端: http://localhost:8000
echo   API文档: http://localhost:8000/docs
echo.
echo   提示: 关闭此窗口不会停止服务
echo   停止服务请运行 stop.bat
echo ========================================
echo.

REM Keep this window open
pause
