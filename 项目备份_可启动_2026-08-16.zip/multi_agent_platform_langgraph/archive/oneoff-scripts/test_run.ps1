# Run and monitor run.bat
$ErrorActionPreference = "SilentlyContinue"

Write-Host "========================================"
Write-Host "  Running run.bat"
Write-Host "========================================"

# Start run.bat and capture output
$proc = Start-Process -FilePath "cmd.exe" -ArgumentList "/c","D:\paper\cc\projects\multi_agent_platform_langgraph\run.bat" -PassThru -NoNewWindow -Wait

# Wait a bit for services to start
Start-Sleep -Seconds 10

# Check ports
Write-Host ""
Write-Host "Checking ports..."
Get-NetTCPConnection -LocalPort 8000,5173 -State Listen | Format-Table -AutoSize

# Check processes
Write-Host ""
Write-Host "Checking processes..."
Get-Process node,python -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*vite*' -or $_.CommandLine -like '*uvicorn*' } | Select-Object Id, ProcessName, CommandLine | Format-Table -AutoSize

# Test endpoints
Write-Host ""
Write-Host "Testing endpoints..."

$backendStatus = "Not responding"
try {
    $backendResponse = Invoke-WebRequest -Uri "http://127.0.0.1:8000/health" -TimeoutSec 5
    $backendStatus = "OK (HTTP $($backendResponse.StatusCode))"
} catch {
    $backendStatus = "Failed: $($_.Exception.Message)"
}

$frontendStatus = "Not responding"
try {
    $frontendResponse = Invoke-WebRequest -Uri "http://localhost:5173" -TimeoutSec 5
    $frontendStatus = "OK (HTTP $($frontendResponse.StatusCode))"
} catch {
    $frontendStatus = "Failed: $($_.Exception.Message)"
}

Write-Host "Backend (8000): $backendStatus"
Write-Host "Frontend (5173): $frontendStatus"

Write-Host ""
Write-Host "Done."
