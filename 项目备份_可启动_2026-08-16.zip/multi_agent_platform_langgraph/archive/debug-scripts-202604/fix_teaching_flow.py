import requests
import sqlite3
import json

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

print('=== 检查并修复教学流程 ===')

# 1. 检查当前状态
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print(f"\n当前状态:")
print(f"  Status: {data['session']['status']}")
print(f"  Phase: {data['session']['current_phase']}")
print(f"  Iteration: {data['session']['current_iteration']}")

# 2. 检查是否有督导消息
has_supervisor = any(m['phase'] == 'supervisor_comment' for m in data.get('messages', []))
print(f"\n督导点评消息: {'已存在' if has_supervisor else '不存在'}")

# 3. 如果流程卡住，尝试手动推动到督导阶段
if data['session']['current_phase'] == 'teacher_answer' and not has_supervisor:
    print("\n>>> 尝试推动到督导点评阶段...")
    res = requests.post(f'{BASE_URL}/api/teaching/sessions/{session_id}/next')
    if res.status_code == 200:
        print("  成功! 已推动到下一阶段")
        result = res.json()
        print(f"  结果: {result}")
    else:
        print(f"  失败: {res.status_code} - {res.text}")

# 4. 再次检查状态
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()
print(f"\n更新后状态:")
print(f"  Status: {data['session']['status']}")
print(f"  Phase: {data['session']['current_phase']}")
print(f"  Message count: {data['message_count']}")

# 检查督导消息
supervisor_msgs = [m for m in data.get('messages', []) if m['phase'] == 'supervisor_comment']
print(f"  督导消息数: {len(supervisor_msgs)}")
for msg in supervisor_msgs:
    print(f"    - {msg['agent_name']}: {len(msg['content'])} chars")
