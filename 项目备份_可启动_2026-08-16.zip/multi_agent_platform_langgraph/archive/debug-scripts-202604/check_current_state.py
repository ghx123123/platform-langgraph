import requests

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

# 检查当前会话状态
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print('=== Phase 2 测试 - 当前状态 ===')
print(f"会话标题: {data['session']['title']}")
print(f"当前状态: {data['session']['status']}")
print(f"当前阶段: {data['session']['current_phase']}")
print(f"当前轮次: {data['session']['current_iteration']}")
print(f"最大轮次: {data['session']['max_iterations']}")
print(f"消息数量: {data['message_count']}")

# 按阶段统计消息
phase_count = {}
agent_count = {}
for msg in data.get('messages', []):
    phase = msg['phase']
    agent = msg['agent_name']
    phase_count[phase] = phase_count.get(phase, 0) + 1
    agent_count[agent] = agent_count.get(agent, 0) + 1

print(f"\n=== 各阶段消息统计 ===")
for phase, count in sorted(phase_count.items()):
    print(f"  {phase}: {count} 条")

print(f"\n=== 各Agent消息统计 ===")
for agent, count in sorted(agent_count.items()):
    print(f"  {agent}: {count} 条")

# 检查学生提问内容
print(f"\n=== 学生提问详情 ===")
for msg in data.get('messages', []):
    if msg['phase'] == 'student_question':
        print(f"  [{msg['agent_name']}]: {msg['content']}")
