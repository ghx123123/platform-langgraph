import requests
import time

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

print('=== 推动到第二轮教学 ===')

# 1. 检查当前状态
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print(f"\n当前状态:")
print(f"  Status: {data['session']['status']}")
print(f"  Phase: {data['session']['current_phase']}")
print(f"  Iteration: {data['session']['current_iteration']}")

# 2. 推动到下一轮
print("\n>>> 推动到第二轮...")
res = requests.post(f'{BASE_URL}/api/teaching/sessions/{session_id}/next')
if res.status_code == 200:
    print("  成功!")
    result = res.json()
    print(f"  结果: {result}")
else:
    print(f"  失败: {res.status_code} - {res.text}")

# 3. 等待第二轮开始
print("\n=== 等待第二轮教学开始 ===")
for i in range(5):
    time.sleep(3)
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    data = res.json()
    
    print(f"\n检查 #{i+1}:")
    print(f"  Phase: {data['session']['current_phase']}")
    print(f"  Iteration: {data['session']['current_iteration']}")
    print(f"  Total messages: {data['message_count']}")
    
    # 检查是否有第二轮的教学内容
    teach_msgs = [m for m in data.get('messages', []) 
                  if m['phase'] == 'teach_knowledge' and m['iteration'] == 1]
    if teach_msgs:
        print(f"  第二轮讲授消息: {len(teach_msgs)} 条")
        for msg in teach_msgs:
            print(f"    - {msg['agent_name']}: {len(msg['content'])} chars")
        print("\n[OK] 第二轮教学内容已开始生成!")
        break

# 最终状态
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print(f"\n=== 最终状态 ===")
print(f"Status: {data['session']['status']}")
print(f"Phase: {data['session']['current_phase']}")
print(f"Iteration: {data['session']['current_iteration']}")
print(f"Total messages: {data['message_count']}")
