import requests

BASE_URL = 'http://localhost:8001'

print('=== 测试API ===')

# 测试获取会话列表
res = requests.get(f'{BASE_URL}/api/teaching/sessions')
print(f"\n1. 会话列表: {res.status_code}")
if res.status_code == 200:
    data = res.json()
    print(f"   会话数量: {len(data.get('sessions', []))}")

# 获取第一个会话ID
if res.status_code == 200 and data.get('sessions'):
    session_id = data['sessions'][0]['id']
    print(f"\n2. 测试会话详情 (ID: {session_id[:8]}...)")
    
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    print(f"   状态: {res.status_code}")
    if res.status_code == 200:
        session_data = res.json()
        print(f"   标题: {session_data['session']['title']}")
        print(f"   消息数: {session_data['message_count']}")
        
        # 检查是否有teach_knowledge消息
        teach_msgs = [m for m in session_data.get('messages', []) if m['phase'] == 'teach_knowledge']
        supervisor_msgs = [m for m in session_data.get('messages', []) if m['phase'] == 'supervisor_comment']
        print(f"   讲授消息: {len(teach_msgs)}")
        print(f"   督导消息: {len(supervisor_msgs)}")

print("\n=== 测试完成 ===")
