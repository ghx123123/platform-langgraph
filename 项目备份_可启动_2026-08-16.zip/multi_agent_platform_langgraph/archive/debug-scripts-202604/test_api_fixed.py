import requests

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'

# 测试获取会话详情
print('=== 测试 get_session API ===')
res = requests.get(f'http://localhost:8000/api/teaching/sessions/{session_id}')
if res.status_code == 200:
    data = res.json()
    print(f"Session status: {data['session']['status']}")
    print(f"Message count: {data['message_count']}")
    for msg in data.get('messages', []):
        print(f"  - {msg['phase']}: {msg['agent_name']} ({len(msg['content'])} chars)")
else:
    print(f"Error: {res.status_code} - {res.text}")

# 测试获取消息
print('\n=== 测试 get_messages API ===')
res = requests.get(f'http://localhost:8000/api/teaching/sessions/{session_id}/messages')
if res.status_code == 200:
    data = res.json()
    print(f"Message count: {data['message_count']}")
    for msg in data.get('messages', []):
        print(f"  - {msg['phase']}: {msg['agent_name']} ({len(msg['content'])} chars)")
        if msg['phase'] == 'teach_knowledge':
            print(f"    Content preview: {msg['content'][:200]}...")
else:
    print(f"Error: {res.status_code} - {res.text}")
