import requests

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

# 测试 messages 端点
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}/messages')
data = res.json()

print('=== /messages 端点返回 ===')
print(f"Message count: {data['message_count']}")
for msg in data.get('messages', []):
    print(f"\n  Phase: {msg['phase']}")
    print(f"  Agent: {msg['agent_name']} (ID: {msg['agent_id'][:20]}...)")
    print(f"  Content length: {len(msg['content'])}")
