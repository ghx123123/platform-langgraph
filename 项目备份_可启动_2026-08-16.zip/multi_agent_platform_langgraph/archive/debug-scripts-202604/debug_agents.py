import requests

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

# 测试获取会话详情
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print('=== Agents ===')
for agent in data.get('agents', []):
    print(f"  ID: {agent['id']}")
    print(f"  Name: {agent['name']}")
    print(f"  Type: {agent['agent_type']}")
    print()

print('=== Messages with agent_id ===')
for msg in data.get('messages', [])[:5]:  # 只显示前5条
    print(f"  Msg ID: {msg['id'][:20]}...")
    print(f"  Agent ID: {msg['agent_id']}")
    print(f"  Agent Name: {msg['agent_name']}")
    print(f"  Phase: {msg['phase']}")
    print()

# 检查消息中的agent_id是否在agents列表中
agent_ids = {a['id'] for a in data.get('agents', [])}
print(f'\nAgent IDs in session: {agent_ids}')
print(f'\nChecking message agent_ids...')
for msg in data.get('messages', []):
    if msg['agent_id'] not in agent_ids:
        print(f"  MISSING: {msg['agent_id']} (msg: {msg['phase']})")
