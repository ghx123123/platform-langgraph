import requests
import time

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

print('=== 等待督导点评完成 ===')

# 等待并检查督导消息
for i in range(10):
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    data = res.json()
    
    supervisor_msgs = [m for m in data.get('messages', []) if m['phase'] == 'supervisor_comment']
    print(f"\n检查 #{i+1}:")
    print(f"  Phase: {data['session']['current_phase']}")
    print(f"  督导消息数: {len(supervisor_msgs)}")
    for msg in supervisor_msgs:
        print(f"    - {msg['agent_name']}: {len(msg['content'])} chars")
    
    if len(supervisor_msgs) >= 2:
        print("\n✅ 两位督导都已完成点评!")
        break
    
    if i < 9:
        print("  等待5秒...")
        time.sleep(5)

# 最终状态
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print(f"\n=== 最终状态 ===")
print(f"Status: {data['session']['status']}")
print(f"Phase: {data['session']['current_phase']}")
print(f"Iteration: {data['session']['current_iteration']}")
print(f"Total messages: {data['message_count']}")

# 显示督导点评内容
print(f"\n=== 督导点评内容 ===")
for msg in data.get('messages', []):
    if msg['phase'] == 'supervisor_comment':
        print(f"\n[{msg['agent_name']}]: {msg['content'][:200]}...")
