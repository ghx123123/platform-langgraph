import sqlite3
import sys

# 设置编码
sys.stdout.reconfigure(encoding='utf-8')

conn = sqlite3.connect('backend/data/platform.db')
cursor = conn.cursor()

print("=== 清理教师讲授内容错误数据 ===\n")

# 1. 查询所有包含Error的teach_knowledge消息
cursor.execute("""
    SELECT session_id, id, agent_name, iteration, LENGTH(content) as len, content
    FROM teaching_messages
    WHERE phase = 'teach_knowledge'
    AND content LIKE '%Error calling LLM%'
    ORDER BY session_id, iteration
""")

error_msgs = cursor.fetchall()
print(f"找到 {len(error_msgs)} 条错误的教师讲授消息\n")

for msg in error_msgs:
    print(f"Session: {msg[0][:8]}... | ID: {msg[1][:8]}... | Agent: {msg[2]} | Iter: {msg[3]} | Len: {msg[4]}")
    print(f"  内容: {msg[5][:100]}...")
    print()

if error_msgs:
    # 2. 删除这些错误消息
    print(">>> 删除错误的教师讲授消息...")
    cursor.execute("""
        DELETE FROM teaching_messages
        WHERE phase = 'teach_knowledge'
        AND content LIKE '%Error calling LLM%'
    """)
    deleted = cursor.rowcount
    conn.commit()
    print(f"  已删除 {deleted} 条错误消息\n")
    
    # 3. 检查受影响的会话
    affected_sessions = set([msg[0] for msg in error_msgs])
    print(f"受影响的会话: {len(affected_sessions)} 个")
    for sid in affected_sessions:
        print(f"  - {sid}")
else:
    print("没有找到错误的教师讲授消息\n")

# 4. 查询所有会话的讲授消息统计
print("\n=== 各会话讲授消息统计 ===")
cursor.execute("""
    SELECT 
        session_id,
        COUNT(*) as total,
        SUM(CASE WHEN content LIKE '%Error calling LLM%' THEN 1 ELSE 0 END) as error_count
    FROM teaching_messages
    WHERE phase = 'teach_knowledge'
    GROUP BY session_id
""")

for row in cursor.fetchall():
    status = "✓" if row[2] == 0 else f"✗ ({row[2]} errors)"
    print(f"  Session {row[0][:8]}...: {row[1]} 条讲授消息 {status}")

conn.close()
print("\n清理完成！")
