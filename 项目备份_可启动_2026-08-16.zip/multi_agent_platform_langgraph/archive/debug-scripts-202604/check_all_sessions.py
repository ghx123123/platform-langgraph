import requests
import sqlite3

BASE_URL = 'http://localhost:8001'

print('=== 检查所有会话的内容状态 ===\n')

# 获取所有会话
res = requests.get(f'{BASE_URL}/api/teaching/sessions')
if res.status_code != 200:
    print(f"获取会话失败: {res.status_code}")
    exit(1)

sessions = res.json().get('sessions', [])
print(f"总会话数: {len(sessions)}\n")

for session in sessions:
    session_id = session['id']
    title = session['title']
    
    # 获取会话详情
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    if res.status_code != 200:
        print(f"[{title[:30]}...] 获取详情失败")
        continue
    
    data = res.json()
    messages = data.get('messages', [])
    
    # 统计各类消息
    teach_msgs = [m for m in messages if m['phase'] == 'teach_knowledge']
    supervisor_msgs = [m for m in messages if m['phase'] == 'supervisor_comment']
    student_msgs = [m for m in messages if m['phase'] == 'student_question']
    
    # 检查是否有错误内容
    error_msgs = [m for m in messages if 'Error calling LLM' in m.get('content', '')]
    
    print(f"会话: {title[:40]}")
    print(f"  状态: {session['status']}")
    print(f"  讲授: {len(teach_msgs)}条", end='')
    if teach_msgs:
        valid = sum(1 for m in teach_msgs if 'Error calling LLM' not in m.get('content', ''))
        error = len(teach_msgs) - valid
        print(f" (正常:{valid} 错误:{error})")
    else:
        print()
    
    print(f"  督导: {len(supervisor_msgs)}条", end='')
    if supervisor_msgs:
        valid = sum(1 for m in supervisor_msgs if 'Error calling LLM' not in m.get('content', ''))
        error = len(supervisor_msgs) - valid
        print(f" (正常:{valid} 错误:{error})")
    else:
        print()
    
    print(f"  学生: {len(student_msgs)}条")
    print()
