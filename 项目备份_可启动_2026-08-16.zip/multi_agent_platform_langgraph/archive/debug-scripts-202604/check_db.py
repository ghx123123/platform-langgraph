import sqlite3
conn = sqlite3.connect('backend/data/platform.db')
cursor = conn.cursor()

# 查找同名会话
print('=== 查找同名会话 ===')
cursor.execute("SELECT id, title, status, created_at FROM teaching_sessions WHERE title = '测试教学-修复验证'")
sessions = cursor.fetchall()
for row in sessions:
    print(f"ID: {row[0]}, Title: {row[1]}, Status: {row[2]}, Created: {row[3]}")

# 查看每个会话的消息数
print('\n=== 各会话消息详情 ===')
for session in sessions:
    session_id = session[0]
    print(f"\n--- Session: {session_id[:8]}... (Status: {session[2]}) ---")
    cursor.execute("SELECT phase, agent_name, LENGTH(content) as len, iteration FROM teaching_messages WHERE session_id = ? ORDER BY created_at", (session_id,))
    for row in cursor.fetchall():
        print(f"  Phase: {row[0]}, Agent: {row[1]}, Len: {row[2]}, Iter: {row[3]}")

# 查看最新的一个会话
print('\n=== 最新会话 ===')
cursor.execute("SELECT id, title, status, current_phase, iteration FROM teaching_sessions ORDER BY updated_at DESC LIMIT 1")
latest = cursor.fetchone()
if latest:
    print(f"Latest: {latest[0][:8]}..., Title: {latest[1]}, Status: {latest[2]}, Phase: {latest[3]}, Iter: {latest[4]}")

conn.close()
