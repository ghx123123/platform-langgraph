"""
Agent Chat Performance Test
- 创建1个Agent
- 进行10轮对话
- 测量响应时间
"""
import requests
import time
import json

API_BASE = "http://localhost:8000/api"

def test_agent_chat_performance():
    print("=" * 60)
    print("   Agent Chat Performance Test")
    print("=" * 60)

    # 1. 创建Agent
    print("\n[1] 创建测试Agent...")
    agent_data = {
        "name": "PerfTestAgent",
        "role": "你是一个有用的AI助手，简洁回复",
        "description": "性能测试Agent",
        "avatar": "🤖"
    }
    resp = requests.post(f"{API_BASE}/agents", json=agent_data)
    if resp.status_code != 200:
        print(f"  [错误] 创建Agent失败: {resp.text}")
        return

    agent = resp.json()
    agent_id = agent["id"]
    print(f"  [OK] Agent创建成功: {agent['name']} (ID: {agent_id})")

    # 2. 10轮对话测试
    print("\n[2] 开始10轮对话测试...")
    print("-" * 60)

    test_prompts = [
        "你好",
        "你叫什么名字?",
        "今天天气怎么样?",
        "讲个笑话吧",
        "Python和JavaScript有什么区别?",
        "什么是机器学习?",
        "推荐一本书",
        "1+1等于多少?",
        "如何学习编程?",
        "再见"
    ]

    total_time = 0
    response_times = []

    for i, prompt in enumerate(test_prompts, 1):
        start = time.time()

        resp = requests.post(
            f"{API_BASE}/agents/{agent_id}/think",
            json={"prompt": prompt}
        )

        elapsed = time.time() - start
        total_time += elapsed
        response_times.append(elapsed)

        if resp.status_code == 200:
            data = resp.json()
            print(f"  [{i:2d}] {elapsed*1000:>7.2f}ms | {prompt[:20]:<20}")
        else:
            print(f"  [{i:2d}] [错误] {resp.status_code}")

    # 3. 统计结果
    print("-" * 60)
    print(f"\n[3] 性能统计:")
    print(f"  总耗时:     {total_time*1000:.2f}ms")
    print(f"  平均响应:   {sum(response_times)/len(response_times)*1000:.2f}ms")
    print(f"  最快响应:   {min(response_times)*1000:.2f}ms")
    print(f"  最慢响应:   {max(response_times)*1000:.2f}ms")

    # 4. 清理
    print(f"\n[4] 清理测试Agent...")
    resp = requests.delete(f"{API_BASE}/agents/{agent_id}")
    print(f"  [OK] Agent已删除")

    print("\n" + "=" * 60)
    print("   测试完成!")
    print("=" * 60)

if __name__ == "__main__":
    # 检查服务是否运行
    try:
        resp = requests.get(f"{API_BASE}/../health")
        if resp.status_code != 200:
            print("[错误] 后端服务未运行")
            exit(1)
    except requests.exceptions.ConnectionError:
        print("[错误] 无法连接到 http://localhost:8000")
        print("请先运行 run.bat 或启动后端服务")
        exit(1)

    test_agent_chat_performance()
