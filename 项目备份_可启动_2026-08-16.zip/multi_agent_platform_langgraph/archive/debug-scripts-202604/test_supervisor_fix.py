import requests
import time
import sqlite3

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

print('=== 测试督导点评修复 ===')

# 1. 检查当前状态
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print(f"\n当前状态:")
print(f"  Status: {data['session']['status']}")
print(f"  Phase: {data['session']['current_phase']}")
print(f"  Iteration: {data['session']['current_iteration']}")
print(f"  Total messages: {data['message_count']}")

# 2. 检查督导消息
supervisor_msgs = [m for m in data.get('messages', []) if m['phase'] == 'supervisor_comment']
print(f"\n现有督导消息: {len(supervisor_msgs)} 条")
for msg in supervisor_msgs:
    print(f"  - {msg['agent_name']}: {len(msg['content'])} chars")
    if 'Error calling LLM' in msg['content']:
        print(f"    [错误] {msg['content'][:50]}...")

# 3. 删除错误的督导消息
print("\n>>> 删除错误的督导消息...")
conn = None
try:
    conn = sqlite3.connect('backend/data/platform.db')
    cursor = conn.cursor()
    
    # 删除包含Error的督导消息
    cursor.execute("""
        DELETE FROM teaching_messages 
        WHERE session_id = ? AND phase = 'supervisor_comment' 
        AND content LIKE '%Error calling LLM%'
    """, (session_id,))
    
    deleted = cursor.rowcount
    conn.commit()
    print(f"  删除了 {deleted} 条错误督导消息")
    
    # 重置阶段到 teacher_answer
    cursor.execute("""
        UPDATE teaching_sessions 
        SET current_phase = 'teacher_answer' 
        WHERE id = ?
    """, (session_id,))
    conn.commit()
    print(f"  重置阶段到 teacher_answer")
    
except Exception as e:
    print(f"  错误: {e}")
finally:
    if conn:
        conn.close()

# 4. 重新触发督导点评
print("\n>>> 重新触发督导点评...")
res = requests.post(f'{BASE_URL}/api/teaching/sessions/{session_id}/next')
if res.status_code == 200:
    print("  成功! 已进入督导点评阶段")
else:
    print(f"  失败: {res.status_code} - {res.text}")

# 5. 等待督导点评生成
print("\n=== 等待督导点评生成 ===")
for i in range(12):  # 最多等待60秒
    time.sleep(5)
    
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    data = res.json()
    
    supervisor_msgs = [m for m in data.get('messages', []) if m['phase'] == 'supervisor_comment']
    valid_msgs = [m for m in supervisor_msgs if 'Error calling LLM' not in m['content']]
    
    print(f"\n检查 #{i+1} ({(i+1)*5}s):")
    print(f"  Phase: {data['session']['current_phase']}")
    print(f"  督导消息: {len(supervisor_msgs)} 条 (有效: {len(valid_msgs)} 条)")
    
    for msg in supervisor_msgs:
        content_preview = msg['content'][:60] if len(msg['content']) > 60 else msg['content']
        status = "OK" if 'Error calling LLM' not in msg['content'] else "ERR"
        print(f"    [{status}] {msg['agent_name']}: {len(msg['content'])} chars - {content_preview}...")
    
    if len(valid_msgs) >= 2:
        print("\n[成功] 两位督导都已完成有效点评!")
        break

# 最终结果
print("\n=== 最终结果 ===")
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

supervisor_msgs = [m for m in data.get('messages', []) if m['phase'] == 'supervisor_comment']
print(f"督导消息总数: {len(supervisor_msgs)}")

for msg in supervisor_msgs:
    print(f"\n[{msg['agent_name']}] (Iteration {msg['iteration']}):")
    if 'Error calling LLM' in msg['content']:
        print(f"  [失败] {msg['content']}")
    else:
        print(f"  [成功] {len(msg['content'])} chars")
        print(f"  内容: {msg['content'][:300]}...")
