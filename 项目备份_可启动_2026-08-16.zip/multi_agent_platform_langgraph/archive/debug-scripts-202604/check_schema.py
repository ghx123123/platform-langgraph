import sqlite3
conn = sqlite3.connect('backend/data/platform.db')
cursor = conn.cursor()

print("=== teaching_sessions 表结构 ===")
cursor.execute('PRAGMA table_info(teaching_sessions)')
for row in cursor.fetchall():
    print(f"  {row[1]}: {row[2]}")

print("\n=== teaching_agents 表结构 ===")
cursor.execute('PRAGMA table_info(teaching_agents)')
for row in cursor.fetchall():
    print(f"  {row[1]}: {row[2]}")

print("\n=== 会话数据 ===")
cursor.execute("SELECT * FROM teaching_sessions LIMIT 1")
row = cursor.fetchone()
if row:
    for i, col in enumerate(cursor.description):
        print(f"  {col[0]}: {row[i]}")

conn.close()
