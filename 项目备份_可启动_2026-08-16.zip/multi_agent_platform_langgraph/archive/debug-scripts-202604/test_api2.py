import requests

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'

# 获取消息
res = requests.get(f'http://localhost:8000/api/teaching/sessions/{session_id}/messages')
data = res.json()

print('=== Messages from API ===')
for msg in data.get('messages', []):
    print(f"\n  ID: {msg['id'][:8]}...")
    print(f"  Phase: {msg['phase']}, Agent: {msg['agent_name']}, Iter: {msg['iteration']}")
    content = msg.get('content', '')
    print(f"  Content (first 300 chars): {content[:300] if content else 'EMPTY'}")
    print(f"  Content length: {len(content) if content else 0}")

print(f"\nTotal messages: {len(data.get('messages', []))}")
