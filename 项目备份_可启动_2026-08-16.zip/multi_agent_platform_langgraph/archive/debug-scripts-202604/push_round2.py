import requests
import time

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

print('=== 推动第二轮流程 ===')

# 推动到下一阶段
phases = ['teach_knowledge', 'student_question', 'teacher_answer', 'supervisor_comment']

for i, phase in enumerate(phases):
    # 检查当前状态
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    data = res.json()
    current_phase = data['session']['current_phase']
    
    print(f"\n步骤 {i+1}: 当前阶段 {current_phase}")
    
    if current_phase == 'completed':
        print("  教学已完成!")
        break
    
    # 如果已经在目标阶段或之后，跳过
    if current_phase not in phases:
        print(f"  当前阶段 {current_phase} 不在预期阶段列表中，跳过")
        continue
    
    current_idx = phases.index(current_phase)
    if current_idx >= i:
        print(f"  推动到下一阶段...")
        res = requests.post(f'{BASE_URL}/api/teaching/sessions/{session_id}/next')
        if res.status_code == 200:
            print(f"  成功!")
        else:
            print(f"  失败: {res.status_code} - {res.text}")
    
    # 等待内容生成
    print("  等待10秒让内容生成...")
    time.sleep(10)

# 最终状态
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print(f"\n=== 第二轮最终状态 ===")
print(f"Status: {data['session']['status']}")
print(f"Phase: {data['session']['current_phase']}")
print(f"Iteration: {data['session']['current_iteration']}")
print(f"Total messages: {data['message_count']}")

# 显示第二轮消息
print(f"\n=== 第二轮消息 ===")
for msg in data.get('messages', []):
    if msg['iteration'] == 1:
        print(f"  [{msg['phase']}] {msg['agent_name']}: {len(msg['content'])} chars")
