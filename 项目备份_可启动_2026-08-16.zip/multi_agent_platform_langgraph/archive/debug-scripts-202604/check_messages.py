import sqlite3
conn = sqlite3.connect('backend/data/platform.db')
cursor = conn.cursor()

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'

print(f'=== 检查会话 {session_id[:8]}... 的消息 ===')
cursor.execute("SELECT COUNT(*) FROM teaching_messages WHERE session_id = ?", (session_id,))
count = cursor.fetchone()[0]
print(f"消息总数: {count}")

cursor.execute("SELECT id, phase, agent_name, LENGTH(content) as len, iteration FROM teaching_messages WHERE session_id = ? ORDER BY created_at", (session_id,))
for row in cursor.fetchall():
    print(f"  ID: {row[0][:8]}..., Phase: {row[1]}, Agent: {row[2]}, Len: {row[3]}, Iter: {row[4]}")

# 查看teach_knowledge的完整内容
cursor.execute("SELECT content FROM teaching_messages WHERE session_id = ? AND phase = 'teach_knowledge' LIMIT 1", (session_id,))
row = cursor.fetchone()
if row:
    print(f"\n=== teach_knowledge 内容 (共{len(row[0])}字符) ===")
    print(row[0][:500])
else:
    print("\n没有找到 teach_knowledge 消息!")

conn.close()
