import sqlite3
conn = sqlite3.connect('backend/data/platform.db')
cursor = conn.cursor()

# 删除completed状态的旧会话，保留teaching状态的新会话
old_session_id = '870f99c5-4ca3-4625-9f1e-7205aad15018'
new_session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'

print(f"删除旧会话: {old_session_id}")
cursor.execute("DELETE FROM teaching_messages WHERE session_id = ?", (old_session_id,))
msg_deleted = cursor.rowcount
cursor.execute("DELETE FROM teaching_sessions WHERE id = ?", (old_session_id,))
session_deleted = cursor.rowcount

print(f"删除了 {msg_deleted} 条消息, {session_deleted} 个会话")

# 验证新会话的内容
print(f"\n验证新会话 {new_session_id[:8]}... 的内容:")
cursor.execute("SELECT phase, agent_name, LENGTH(content) as len FROM teaching_messages WHERE session_id = ? ORDER BY created_at", (new_session_id,))
for row in cursor.fetchall():
    print(f"  Phase: {row[0]}, Agent: {row[1]}, Content Length: {row[2]} chars")

# 查看teach_knowledge的实际内容前200字符
cursor.execute("SELECT content FROM teaching_messages WHERE session_id = ? AND phase = 'teach_knowledge' LIMIT 1", (new_session_id,))
content = cursor.fetchone()
if content:
    print(f"\n=== 教师讲授内容预览 (前300字符) ===")
    print(content[0][:300])
    print(f"\n[总计 {len(content[0])} 字符]")

conn.commit()
conn.close()
print("\n✅ 数据库修复完成")
