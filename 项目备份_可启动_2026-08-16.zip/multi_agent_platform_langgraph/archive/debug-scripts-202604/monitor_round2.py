import requests
import time

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

print('=== Phase 4: 多轮迭代优化测试 - 第二轮监控 ===')

prev_message_count = 0
prev_phase = ""

for i in range(30):  # 最多等待150秒
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    data = res.json()
    
    current_phase = data['session']['current_phase']
    current_iteration = data['session']['current_iteration']
    message_count = data['message_count']
    
    # 只在有变化时输出
    if current_phase != prev_phase or message_count != prev_message_count:
        print(f"\n[{i*5}s] Phase: {current_phase}, Iter: {current_iteration}, Msgs: {message_count}")
        
        # 显示当前阶段的消息
        for msg in data.get('messages', []):
            if msg['iteration'] == 1:  # 第二轮
                print(f"  [{msg['phase']}] {msg['agent_name']}: {len(msg['content'])} chars")
        
        prev_phase = current_phase
        prev_message_count = message_count
    
    # 检查是否完成第二轮
    if current_iteration == 1 and current_phase == 'iteration_complete':
        print("\n第二轮已完成!")
        
        # 显示第二轮所有消息
        print("\n=== 第二轮消息汇总 ===")
        for msg in data.get('messages', []):
            if msg['iteration'] == 1:
                print(f"  [{msg['phase']}] {msg['agent_name']}: {len(msg['content'])} chars")
        break
    
    # 检查是否完成全部教学
    if data['session']['status'] == 'completed':
        print("\n教学已全部完成!")
        break
    
    time.sleep(5)

print("\n监控结束")
