import requests
import os
import time

BASE_URL = 'http://localhost:8001'

# 使用已有的会话ID进行测试
session_id = 'b37b734c-d723-4635-b2cf-a9b84f85722e'

print('=== 测试PDF导出功能 ===\n')

# 1. 获取会话信息
print('>>> 获取会话信息...')
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
if res.status_code != 200:
    print(f'  获取会话失败: {res.status_code}')
    exit(1)

session_data = res.json()
print(f"  会话标题: {session_data['session']['title']}")
print(f"  会话状态: {session_data['session']['status']}")
print(f"  消息数量: {session_data['message_count']}")

# 2. 直接下载PDF（GET请求）
print('\n>>> 下载PDF报告...')
pdf_url = f'{BASE_URL}/api/teaching/sessions/{session_id}/report/pdf?include_quiz=true&include_interactions=true'

res = requests.get(pdf_url)

if res.status_code == 200:
    # 保存PDF文件
    output_path = 'test_report.pdf'
    with open(output_path, 'wb') as f:
        f.write(res.content)
    
    file_size = len(res.content)
    print(f'  PDF下载成功!')
    print(f'  文件大小: {file_size} bytes')
    print(f'  保存路径: {output_path}')
    
    if file_size > 1000:  # 如果文件大于1KB，认为生成成功
        print('\n[成功] PDF导出功能正常工作!')
    else:
        print('\n[警告] PDF文件可能内容不完整')
else:
    print(f'  PDF下载失败: {res.status_code}')
    print(f'  错误信息: {res.text}')

print('\n=== 测试完成 ===')
