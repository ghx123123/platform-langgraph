import requests
import time

BASE_URL = 'http://localhost:8001'

print('=== 测试教师讲授内容修复 ===')

# 1. 创建新会话
print("\n>>> 创建新教学会话...")
res = requests.post(f'{BASE_URL}/api/teaching/sessions', data={
    'title': '教师讲授修复测试',
    'max_iterations': 3
})

if res.status_code != 200:
    print(f"  创建失败: {res.status_code} - {res.text}")
    exit(1)

session_id = res.json()['session']['id']
print(f"  会话ID: {session_id}")

# 2. 启动教学
print("\n>>> 启动教学...")
res = requests.post(f'{BASE_URL}/api/teaching/sessions/{session_id}/start')
print(f"  状态: {res.status_code}")

# 3. 监控教学流程，特别关注讲授内容
print("\n=== 监控教学流程 ===")
for i in range(40):  # 最多监控200秒
    time.sleep(5)
    
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    data = res.json()
    
    phase = data['session']['current_phase']
    iteration = data['session']['current_iteration']
    msg_count = data['message_count']
    
    # 检查讲授消息
    teach_msgs = [m for m in data.get('messages', []) if m['phase'] == 'teach_knowledge']
    
    print(f"[{i+1}] Phase: {phase:20} | Iter: {iteration} | Msgs: {msg_count:2} | Teach: {len(teach_msgs)}")
    
    # 显示讲授消息详情
    for msg in teach_msgs:
        status = "OK" if 'Error calling LLM' not in msg['content'] else "ERR"
        print(f"      [{status}] {msg['agent_name']} Iter{msg['iteration']}: {len(msg['content'])} chars")
    
    # 如果所有轮次的讲授都完成了，退出
    if len(teach_msgs) >= 3:
        all_valid = all('Error calling LLM' not in m['content'] for m in teach_msgs)
        if all_valid:
            print("\n[成功] 所有轮次的讲授内容都正常生成！")
            break
    
    # 如果教学完成或失败
    if data['session']['status'] in ['completed', 'failed']:
        print(f"\n教学状态: {data['session']['status']}")
        break

# 4. 最终结果
print("\n=== 最终结果 ===")
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

teach_msgs = [m for m in data.get('messages', []) if m['phase'] == 'teach_knowledge']
print(f"讲授消息总数: {len(teach_msgs)}")

success_count = 0
for msg in teach_msgs:
    print(f"\n[{msg['agent_name']}] 第{msg['iteration']}轮:")
    if 'Error calling LLM' in msg['content']:
        print(f"  [失败] {msg['content']}")
    else:
        print(f"  [成功] {len(msg['content'])} chars")
        print(f"  预览: {msg['content'][:200]}...")
        success_count += 1

print(f"\n=== 测试结论 ===")
print(f"成功率: {success_count}/{len(teach_msgs)}")
if success_count == len(teach_msgs) and len(teach_msgs) >= 3:
    print("[OK] 教师讲授内容修复成功！所有轮次都正常生成。")
else:
    print("[需要检查] 仍有部分讲授内容生成失败。")
