import requests
import time

BASE_URL = 'http://localhost:8001'

print('=== 创建新会话测试督导点评 ===')

# 1. 创建新会话 (使用Form数据)
print("\n>>> 创建新教学会话...")
res = requests.post(f'{BASE_URL}/api/teaching/sessions', data={
    'title': '督导点评修复测试',
    'max_iterations': 2
})

if res.status_code != 200:
    print(f"  创建失败: {res.status_code} - {res.text}")
    exit(1)

session_id = res.json()['session']['id']
print(f"  会话ID: {session_id}")

# 2. 启动教学
print("\n>>> 启动教学...")
res = requests.post(f'{BASE_URL}/api/teaching/sessions/{session_id}/start')
print(f"  状态: {res.status_code}")

# 3. 等待教学设计完成
print("\n=== 等待教学设计完成 ===")
for i in range(20):
    time.sleep(3)
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    data = res.json()
    
    phase = data['session']['current_phase']
    print(f"  [{i+1}] Phase: {phase}, Msgs: {data['message_count']}")
    
    if phase == 'teach_knowledge' and data['message_count'] >= 2:
        print("  教学设计完成!")
        break

# 4. 推动到督导点评阶段
print("\n>>> 推动到督导点评阶段...")
phases_to_go = ['teach_knowledge', 'student_question', 'teacher_answer', 'supervisor_comment']

for target_phase in phases_to_go[1:]:  # 跳过design
    res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
    data = res.json()
    current_phase = data['session']['current_phase']
    
    print(f"\n  当前阶段: {current_phase}")
    
    if current_phase == target_phase:
        print(f"  已处于 {target_phase} 阶段")
        if target_phase == 'supervisor_comment':
            print("  等待督导点评生成...")
            time.sleep(20)  # 等待督导点评生成
        continue
    
    # 推动到下一阶段
    print(f"  推动到 {target_phase}...")
    res = requests.post(f'{BASE_URL}/api/teaching/sessions/{session_id}/next')
    if res.status_code == 200:
        print(f"  成功!")
    else:
        print(f"  失败: {res.status_code}")
    
    if target_phase == 'supervisor_comment':
        print("  等待督导点评生成...")
        time.sleep(20)

# 5. 检查督导点评
print("\n=== 检查督导点评结果 ===")
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

supervisor_msgs = [m for m in data.get('messages', []) if m['phase'] == 'supervisor_comment']
print(f"督导消息数: {len(supervisor_msgs)}")

success_count = 0
for msg in supervisor_msgs:
    print(f"\n[{msg['agent_name']}]:")
    if 'Error calling LLM' in msg['content']:
        print(f"  [失败] {msg['content'][:80]}...")
    else:
        print(f"  [成功] {len(msg['content'])} chars")
        print(f"  内容: {msg['content'][:200]}...")
        success_count += 1

print(f"\n=== 测试结果 ===")
print(f"督导点评成功率: {success_count}/{len(supervisor_msgs)}")
if success_count == len(supervisor_msgs) and len(supervisor_msgs) >= 2:
    print("[成功] 督导点评修复成功!")
else:
    print("[需要检查] 仍有督导点评生成失败")
