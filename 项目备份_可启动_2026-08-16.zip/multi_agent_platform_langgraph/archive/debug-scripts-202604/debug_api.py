import requests
import json

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'
BASE_URL = 'http://localhost:8001'

# 测试获取会话详情
print('=== get_session API 返回 ===')
res = requests.get(f'{BASE_URL}/api/teaching/sessions/{session_id}')
data = res.json()

print(f"Session: {data['session']['title']}")
print(f"Status: {data['session']['status']}")
print(f"Phase: {data['session']['current_phase']}")
print(f"Message count: {data['message_count']}")
print(f"\nMessages detail:")
for msg in data.get('messages', []):
    print(f"\n  ID: {msg['id']}")
    print(f"  Phase: {msg['phase']}")
    print(f"  Agent: {msg['agent_name']} (Type: {msg['agent_type']})")
    print(f"  Iteration: {msg['iteration']}")
    print(f"  Content length: {len(msg['content'])}")
    print(f"  Content preview: {msg['content'][:100]}...")
