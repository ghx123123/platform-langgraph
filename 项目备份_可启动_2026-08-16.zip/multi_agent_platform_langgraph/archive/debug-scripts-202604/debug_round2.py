import sqlite3

conn = sqlite3.connect('backend/data/platform.db')
cursor = conn.cursor()

session_id = '6d50bb69-bd52-4cb6-9ac6-43a829126e25'

print('=== 检查第二轮消息详情 ===')
cursor.execute("""
    SELECT phase, agent_name, LENGTH(content) as len, iteration 
    FROM teaching_messages 
    WHERE session_id = ? 
    ORDER BY iteration, created_at
""", (session_id,))

for row in cursor.fetchall():
    print(f"  Iter {row[3]} | {row[0]:20} | {row[1]:10} | {row[2]} chars")

conn.close()
